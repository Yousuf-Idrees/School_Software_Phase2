package com.school.model;

public class AttendanceRecord {
    private String id;
    private String studentId;
    private String date;
    private String presenceStatus;

    public AttendanceRecord() {}

    public AttendanceRecord(String id, String studentId, String date, String presenceStatus) {
        this.id = id;
        this.studentId = studentId;
        this.date = date;
        this.presenceStatus = presenceStatus;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPresenceStatus() {
        return presenceStatus;
    }

    public void setPresenceStatus(String presenceStatus) {
        this.presenceStatus = presenceStatus;
    }

    @Override
    public String toString() {
        return "AttendanceRecord{" +
                "id='" + id + '\'' +
                ", studentId='" + studentId + '\'' +
                ", date='" + date + '\'' +
                ", presenceStatus='" + presenceStatus + '\'' +
                '}';
    }
}
