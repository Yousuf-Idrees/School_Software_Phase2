package com.school.assignments;

/**
 * Implementor interface for the Bridge Pattern
 * Defines the interface for different storage implementations
 */
public interface Storage {
    void store(String fileName);
}
