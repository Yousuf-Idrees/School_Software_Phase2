package com.school.grades;

public interface GradeExporter {
    void exportGrades(String studentId, String reportData);
}
