# Development View - Component Integration Guide

## Overview
This document describes how the implemented components work together in the school software system, with emphasis on the modular architecture, design patterns, and third-party integration points.

---

## Component Implementation Summary

### 1. Attendance Marking System

#### Files Implemented
- **AttendanceRecord.java** - Data model for attendance records
- **IAttendanceMarkingService.java** - Interface defining attendance operations
- **AttendanceMarkingService.java** - Service implementation with validation
- **AttendanceMarkingController.java** - Controller layer with REST-like operations

#### Key Methods
```
markAttendance(studentId, date, presenceStatus) -> AttendanceRecord
updateAttendance(recordId, studentId, date, presenceStatus) -> AttendanceRecord
deleteAttendance(recordId) -> boolean
getAttendanceRecord(recordId) -> AttendanceRecord
validateAttendanceData(studentId, date, presenceStatus) -> void
```

#### Template Method Pattern Implementation
- **AttendanceProcess** (Abstract Template)
  - QRAttendance: Concrete workflow for QR-based marking
  - ManualAttendance: Concrete workflow for manual entry
- Each workflow defines standard steps: validate → mark → notify

#### Validation Rules
- StudentId: Non-empty string
- Date: Valid date format (YYYY-MM-DD)
- PresenceStatus: "Present", "Absent", or "Late"

---

### 2. Notification System (Bridge Pattern)

#### Files Implemented
- **INotificationSender.java** - Interface for notification delivery
- **INotificationManager.java** - Interface for notification coordination
- **NotificationManagerImpl.java** - Central notification manager
- **EmailNotificationSender.java** - Email delivery implementation
- **InAppNotificationSender.java** - In-app notification storage
- **SMSGatewayAdapter.java** - Adapter for third-party SMS service

#### Architecture
```
NotificationManager (Abstraction)
  ├── NotificationDeliveryStrategy (Bridge)
  │   ├── EmailNotificationSender
  │   ├── InAppNotificationSender
  │   └── SMSGatewayAdapter
  └── ExternalSMSService (Third-Party)
```

#### Registration & Usage
```java
NotificationManagerImpl manager = new NotificationManagerImpl(userRepository);
manager.registerNotificationStrategy("EMAIL", new EmailNotificationSender());
manager.registerNotificationStrategy("SMS", new SMSGatewayAdapter(apiKey, endpoint));
manager.setDefaultStrategy("SMS");
manager.sendNotificationToStudent(studentId, message, "SMS");
```

---

### 3. Grade Viewer System

#### Files Implemented
- **IGradeViewerService.java** - Interface for grade viewing (Singleton pattern)
- **GradeViewerServiceImpl.java** - Singleton implementation
- **IGradeExportService.java** - Interface for grade exporting (Strategy pattern)
- **GradeExportServiceImpl.java** - Strategy implementation

#### Singleton Implementation
```
GradeViewerServiceImpl.getInstance(userRepository)
  - Ensures single instance
  - Thread-safe access to grade database
  - Reduces connection overhead
```

#### Strategy Pattern for Export
```
GradeExportService
  ├── CSVGradeExportStrategy
  ├── PDFGradeExportStrategy
  └── PlainTextGradeExportStrategy
```

#### Key Methods
```
viewGrades(studentId) -> List<Object>
getGradeByStudentAndCourse(studentId, courseId) -> Object
exportGradesToCSV(studentId) -> String
exportGradesToPDF(studentId) -> String
exportGradesToPlainText(studentId) -> String
getExportedFileBytes(studentId, format) -> byte[]
```

---

### 4. SMS Gateway Adapter (Third-Party Integration)

#### Files Implemented
- **IExternalSMSService.java** - Third-party service interface
- **ExternalSMSServiceImpl.java** - HTTP-based SMS implementation
- **SMSGatewayAdapter.java** - Adapter connecting to INotificationSender

#### Adapter Pattern
```
External SMS Service (Third-Party API)
         ↓ (HTTP POST)
ExternalSMSServiceImpl
         ↓ (Interface Adaptation)
SMSGatewayAdapter
         ↓ (NotificationSender)
NotificationManager
```

#### Configuration
```java
SMSGatewayAdapter adapter = new SMSGatewayAdapter(apiKey, endpoint);
adapter.setCredentials(apiKey, "https://api.sms-provider.com/send");
manager.registerNotificationStrategy("SMS", adapter);
```

#### External API Integration
- Validates phone numbers (10-15 digits)
- Escapes JSON message content
- Performs HTTP POST to external endpoint
- Handles authentication via API key
- Returns true/false for success/failure

---

## Dependency Injection & Integration

### Using SchoolSystemFacade (Recommended)
```java
SchoolSystemFacade system = new SchoolSystemFacade(userRepo, attendanceRepo);

system.initializeEmailNotifications();
system.initializeInAppNotifications();
system.initializeSMSGateway(apiKey, endpoint);

system.sendNotificationToStudent(studentId, "Attendance marked", "SMS");
system.getAttendanceController().markAttendance(studentId, date, status);
system.getGradeViewerService().viewGrades(studentId);
```

### Direct Component Usage
```java
AttendanceMarkingService attService = new AttendanceMarkingService(repo);
AttendanceMarkingController attController = new AttendanceMarkingController(attService);

Map<String, Object> result = attController.markAttendance(studentId, date, status);
if ((Boolean) result.get("success")) {
    AttendanceRecord record = (AttendanceRecord) result.get("data");
}
```

---

## Design Patterns Applied

| Component | Pattern | Benefit |
|-----------|---------|---------|
| AttendanceProcess | Template Method | Define workflow steps once, reuse across implementations |
| NotificationManager | Strategy | Switch notification channels without modifying code |
| GradeViewer | Singleton | Single database connection, reduced overhead |
| GradeExport | Strategy | Support multiple export formats independently |
| SMSGateway | Adapter | Connect third-party service without coupling |
| UserAccountFactory | Abstract Factory | Create UI families based on user type |

---

## Error Handling

### Validation Errors
- Missing required fields return "Bad Request"
- Invalid data formats return descriptive error messages
- All exceptions include specific context

### Not Found Errors
- Non-existent attendance records return "Not Found" status
- Specific record ID included in error message

### Integration Errors
- SMS delivery failures are logged but don't block other notifications
- Third-party service timeouts gracefully degrade
- Fallback to alternative notification channels

---

## Database Integration

### AttendanceRepository Interface Expected
```
save(AttendanceRecord) -> void
update(AttendanceRecord) -> void
delete(String recordId) -> void
findById(String recordId) -> AttendanceRecord
findByStudentId(String studentId) -> List<AttendanceRecord>
```

### UserRepository Interface Expected
```
findById(String userId) -> Object
findByEmail(String email) -> Object
save(Object user) -> void
update(Object user) -> void
```

---

## Security Considerations

### Validation
- All inputs validated before processing
- Phone numbers normalized and validated
- Student IDs cross-referenced with database
- Attendance status restricted to predefined values

### SMS Gateway
- API key stored securely (not in code)
- HTTPS for external communication
- Message content escaped to prevent injection
- Rate limiting recommended for production

### Notifications
- Access control recommended (not implemented)
- Audit logging recommended for compliance
- Notification delivery status tracked

---

## Data Flow Diagrams

### Attendance Marking Flow
```
User Input
    ↓
AttendanceMarkingController.markAttendance()
    ↓
AttendanceMarkingService.validateAttendanceData()
    ↓
AttendanceRepository.save()
    ↓
Database
    ↓
(Success) Trigger AttendanceAlertListener
    ↓
NotificationManager.sendNotificationToStudent()
    ↓
SMSGatewayAdapter.send()
    ↓
ExternalSMSService.sendSMS()
    ↓
Third-Party SMS Provider
```

### Grade Export Flow
```
User Request (view grades)
    ↓
GradeController
    ↓
IGradeViewerService.viewGrades()
    ↓
DatabaseQuery
    ↓
(If export requested)
IGradeExportService.exportGradesToCSV/PDF/Text()
    ↓
GradeExportStrategy implementation
    ↓
File/String output
    ↓
User receives formatted grades
```

### Notification Delivery Flow
```
Event (Attendance marked, Grade posted, etc.)
    ↓
NotificationManager.sendNotificationToStudent()
    ↓
Strategy selection (SMS/Email/InApp)
    ↓
INotificationSender.send()
    ↓
├─ EmailNotificationSender (SMTP)
├─ InAppNotificationSender (Database)
└─ SMSGatewayAdapter
      ↓
   ExternalSMSService
      ↓
   Third-Party API
```

---

## Usage Examples

### Example 1: Mark Attendance and Send Alert
```java
AttendanceMarkingController controller = new AttendanceMarkingController(repo);
Map<String, Object> result = controller.markAttendance("STU-001", "2026-05-16", "Present");

if ((Boolean) result.get("success")) {
    notificationManager.sendNotificationToStudent("STU-001", 
        "Your attendance for 2026-05-16 has been marked", "SMS");
}
```

### Example 2: Export Grades
```java
IGradeExportService exportService = new GradeExportServiceImpl();
String csvData = exportService.exportGradesToCSV("STU-001");
byte[] pdfData = exportService.getExportedFileBytes("STU-001", "pdf");
```

### Example 3: Send Multi-Channel Notification
```java
List<String> studentIds = Arrays.asList("STU-001", "STU-002", "STU-003");
notificationManager.sendNotificationToStudents(studentIds, 
    "Final exam scheduled for 2026-06-01", "EMAIL");
notificationManager.sendNotificationToStudents(studentIds, 
    "Reminder: Final exam tomorrow", "SMS");
```

---

## Future Extensions

### Potential Enhancements
1. **Biometric Attendance** - Extend AttendanceProcess with fingerprint scanning
2. **Push Notifications** - Add NotificationSender implementation for push services
3. **Slack Integration** - Create SMSGatewayAdapter-like adapter for Slack API
4. **Report Generation** - Implement Template Method for different report formats
5. **Attendance Analytics** - Add service for attendance pattern analysis
6. **Multi-language Notifications** - Add message translation layer
7. **Attendance Approval Workflow** - Add approval step before final marking
8. **Notification Scheduling** - Queue notifications for delayed delivery

---

## Testing Strategy

### Unit Tests
- Test validation logic in AttendanceMarkingService
- Test adapter transformation in SMSGatewayAdapter
- Test strategy selection in NotificationManager

### Integration Tests
- Test full attendance marking workflow
- Test notification delivery to multiple channels
- Test grade export in different formats

### Mock Objects
- Mock ExternalSMSService for SMS testing
- Mock AttendanceRepository for persistence testing
- Mock UserRepository for grade viewer testing

