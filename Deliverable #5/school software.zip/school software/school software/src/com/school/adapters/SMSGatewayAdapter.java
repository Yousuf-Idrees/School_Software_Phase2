package com.school.adapters;

import com.school.model.INotificationSender;
import com.school.model.NotificationDeliveryStrategy;

public class SMSGatewayAdapter implements INotificationSender, NotificationDeliveryStrategy {
    private IExternalSMSService externalService;
    private String apiKey;
    private String endpoint;

    public SMSGatewayAdapter(String apiKey, String endpoint) {
        this.apiKey = apiKey;
        this.endpoint = endpoint;
        this.externalService = new ExternalSMSServiceImpl(apiKey, endpoint);
    }

    public SMSGatewayAdapter(IExternalSMSService externalService) {
        this.externalService = externalService;
    }

    @Override
    public void send(String recipient, String message) throws Exception {
        if (!validate(recipient)) {
            throw new Exception("Invalid recipient format for SMS: " + recipient);
        }
        
        externalService.sendSMS(recipient, message);
    }

    @Override
    public boolean validate(String recipient) {
        return externalService.validatePhoneNumber(recipient);
    }

    @Override
    public void sendNotification(String recipient, String message) {
        try {
            send(recipient, message);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void setCredentials(String apiKey, String endpoint) {
        this.apiKey = apiKey;
        this.endpoint = endpoint;
        this.externalService = new ExternalSMSServiceImpl(apiKey, endpoint);
    }
}
