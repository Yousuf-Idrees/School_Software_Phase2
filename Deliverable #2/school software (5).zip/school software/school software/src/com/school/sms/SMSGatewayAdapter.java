package com.school.sms;

public class SMSGatewayAdapter implements NotificationSender {

    private ThirdPartySMSGateway gateway;

    public SMSGatewayAdapter(ThirdPartySMSGateway gateway) {
        this.gateway = gateway;
    }

    @Override
    public void send(String recipient, String message) {
        gateway.dispatch(recipient, message);
    }
}
