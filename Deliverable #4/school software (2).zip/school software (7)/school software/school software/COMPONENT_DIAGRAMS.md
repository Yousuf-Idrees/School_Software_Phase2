# Component Diagram - Visual Architecture

## System Component Diagram

```mermaid
graph TB
    subgraph UI["UI Layer"]
        SMSAlert["SMSAlertPanel"]
        ExamNotifPanel["ExamNotificationPanel"]
        AnnouncementPanel["AnnouncementPanel"]
        StudentPanel["StudentPanel"]
        GradeView["Grade Viewer UI"]
        AttendanceUI["Attendance UI"]
    end

    subgraph Controllers["Controller Layer"]
        GradeCtrl["GradeController"]
        AttendCtrl["AttendanceController"]
        ReportCtrl["ReportController"]
        SchoolCtrl["SchoolController"]
    end

    subgraph NotifComponent["Notification Component"]
        NotifMgr["NotificationManager"]
        NotifSystem["NotificationSystem"]
        NotifDelivery["NotificationDeliveryClient"]
        
        subgraph Strategies["Notification Strategies"]
            EmailStrat["EmailNotificationStrategy"]
            SMSStrat["SMSNotificationStrategy"]
            InAppStrat["InAppNotificationStrategy"]
        end
        
        NotifMgr --> Strategies
        NotifSystem --> NotifMgr
    end

    subgraph GradeComponent["Grade Viewer Component"]
        GradeService["GradeViewerService\n(Singleton)"]
        GradeExporter["GradeExporter"]
        GradeExportCtx["GradeExporterContext"]
        
        subgraph ExportStrategies["Export Strategies"]
            CSVExport["CSVGradeExportStrategy"]
            PDFExport["PDFGradeExportStrategy"]
            TextExport["PlainTextGradeExportStrategy"]
        end
        
        ReportGen["ReportGenerationService"]
        ReportMgr["ReportManager"]
        
        GradeExportCtx --> ExportStrategies
        GradeExporter --> GradeExportCtx
        ReportGen --> ReportMgr
    end

    subgraph AttendComponent["Attendance Component"]
        AttendCtrl --> AttendDAO
        AttendDAO["AttendanceDAO"]
        
        subgraph AttendMethods["Attendance Methods\nTemplate Method Pattern"]
            Manual["ManualAttendance"]
            QR["QRAttendance"]
        end
        
        SeatMgr["SeatManager"]
        EventMgr["EventManager"]
        AttendListener["AttendanceAlertListener"]
        
        AttendDAO --> AttendMethods
        EventMgr --> AttendListener
    end

    subgraph Factories["Abstract Factory Pattern"]
        DocFactory["DocumentFactory"]
        UserFactory["UserAccountFactory"]
        
        subgraph DocImpl["Document Factories"]
            PDFFactory["PDFDocumentFactory"]
            WordFactory["WordDocumentFactory"]
        end
        
        subgraph UserImpl["User Account Factories"]
            StudentFactory["StudentAccountFactory"]
            TeacherFactory["TeacherAccountFactory"]
        end
        
        DocFactory --> DocImpl
        UserFactory --> UserImpl
    end

    subgraph DataLayer["Data Access Layer"]
        UserRepo["UserRepository"]
        AttendRepo["AttendanceRepository"]
        DBConn["DatabaseConnection"]
    end

    subgraph ThirdParty["Third-Party Integration"]
        SMSAdapter["SMSGatewayAdapter"]
        ExternalSMS["External SMS Gateway\n(e.g., Twilio)"]
        
        SMSAdapter --> ExternalSMS
    end

    GradeCtrl --> GradeComponent
    AttendCtrl --> AttendComponent
    ReportCtrl --> ReportComponent
    SchoolCtrl --> UI

    GradeComponent --> DataLayer
    AttendComponent --> DataLayer
    NotifComponent --> DataLayer
    NotifComponent --> ThirdParty

    Strategies --> ThirdParty
    SMSStrat --> SMSAdapter

    DataLayer --> DBConn

    UI --> Controllers
    UI --> NotifComponent
    UI --> GradeComponent
    UI --> AttendComponent

    style NotifComponent fill:#e1f5ff
    style GradeComponent fill:#f3e5f5
    style AttendComponent fill:#e8f5e9
    style Factories fill:#fff3e0
    style ThirdParty fill:#ffe0b2
    style DataLayer fill:#f1f8e9
```

---

## Notification Component - Detailed Structure

```mermaid
graph LR
    subgraph NotifCore["Notification System Core"]
        NotifSys["NotificationSystem"]
        NotifMgr["NotificationManager"]
        NotifClient["NotificationDeliveryClient"]
    end

    subgraph BridgePattern["Bridge Pattern\nAbstraction vs Implementation"]
        ExamNotif["ExamNotification"]
        Midterm["MidtermNotification"]
        Final["FinalNotification"]
        
        NotifSender["NotificationSender\nInterface"]
        EmailSender["EmailSender"]
        SMSSender["SMSSender"]
        PushSender["PushNotificationSender"]
        
        Midterm -.->|uses| NotifSender
        Final -.->|uses| NotifSender
    end

    subgraph StrategyPattern["Strategy Pattern"]
        Strategy["NotificationDeliveryStrategy"]
        Email["EmailNotificationStrategy"]
        SMS["SMSNotificationStrategy"]
        InApp["InAppNotificationStrategy"]
    end

    subgraph Decorators["Decorator Pattern"]
        BasicNotif["BasicNotification"]
        Decorator["NotificationDecorator"]
        EmailDecorator["EmailDecorator"]
        SMSDecorator["SMSDecorator"]
        
        EmailDecorator -->|wraps| BasicNotif
        SMSDecorator -->|wraps| EmailDecorator
    end

    subgraph Listeners["Observer Pattern"]
        EventMgr["EventManager"]
        AttendListener["AttendanceAlertListener"]
        EventListener["EventListener"]
    end

    NotifSys --> NotifMgr
    NotifMgr --> StrategyPattern
    NotifClient --> NotifMgr
    EventMgr --> Listeners
    Listeners -->|trigger| NotifMgr

    style BridgePattern fill:#c8e6c9
    style StrategyPattern fill:#bbdefb
    style Decorators fill:#ffe0b2
    style Listeners fill:#f8bbd0
```

---

## Grade Viewer Component - Detailed Structure

```mermaid
graph LR
    subgraph Controllers["Controller Layer"]
        GradeCtrl["GradeController"]
        ReportCtrl["ReportController"]
    end

    subgraph Services["Service Layer"]
        GradeService["GradeViewerService\n(Singleton)"]
        ReportService["ReportGenerationService"]
    end

    subgraph ExportStrategy["Export Strategy Pattern"]
        Context["GradeExporterContext"]
        Strategy["GradeExportStrategy\nInterface"]
        
        subgraph Strategies["Concrete Strategies"]
            CSV["CSVGradeExportStrategy"]
            PDF["PDFGradeExportStrategy"]
            Text["PlainTextGradeExportStrategy"]
        end
        
        Context -->|delegates to| Strategy
        Strategy -->|implements| Strategies
    end

    subgraph DocumentFactory["Abstract Factory Pattern"]
        DocFactory["DocumentFactory\nInterface"]
        
        subgraph PDFFamily["PDF Document Family"]
            PDFFactory["PDFDocumentFactory"]
            PDFHeader["PDFHeader"]
            PDFBody["PDFBody"]
            PDFFooter["PDFFooter"]
            
            PDFFactory -->|creates| PDFHeader
            PDFFactory -->|creates| PDFBody
            PDFFactory -->|creates| PDFFooter
        end
        
        subgraph WordFamily["Word Document Family"]
            WordFactory["WordDocumentFactory"]
            WordHeader["WordHeader"]
            WordBody["WordBody"]
            WordFooter["WordFooter"]
            
            WordFactory -->|creates| WordHeader
            WordFactory -->|creates| WordBody
            WordFactory -->|creates| WordFooter
        end
        
        DocFactory -->|implements| PDFFactory
        DocFactory -->|implements| WordFactory
    end

    GradeCtrl --> Services
    ReportCtrl --> Services
    Services --> ExportStrategy
    PDF -->|uses| DocumentFactory

    style Services fill:#f3e5f5
    style ExportStrategy fill:#bbdefb
    style DocumentFactory fill:#fff9c4
```

---

## Attendance Marking Component - Detailed Structure

```mermaid
graph TB
    subgraph Controller["Controller"]
        AttendCtrl["AttendanceController"]
    end

    subgraph TemplateMethod["Template Method Pattern\nAttendance Workflow"]
        Base["AttendanceProcess\nAbstract Template"]
        
        subgraph Manual["Manual Attendance"]
            ManAtt["ManualAttendance"]
            ManInit["initiateAttendance"]
            ManMark["markPresence"]
            ManReport["generateReport"]
            
            ManAtt --> ManInit
            ManAtt --> ManMark
            ManAtt --> ManReport
        end
        
        subgraph QRBased["QR Code Attendance"]
            QRAtt["QRAttendance"]
            QRInit["initiateQRCodeGeneration"]
            QRScan["scanAndMarkPresence"]
            QRReport["generateReport"]
            
            QRAtt --> QRInit
            QRAtt --> QRScan
            QRAtt --> QRReport
        end
        
        Base -->|extended by| ManAtt
        Base -->|extended by| QRAtt
    end

    subgraph DataAccess["Data Access Layer"]
        DAO["AttendanceDAO"]
        Repo["AttendanceRepository"]
    end

    subgraph Support["Support Classes"]
        Classroom["Classroom"]
        SeatMgr["SeatManager"]
        Seat["Seat"]
        StudentCollection["StudentCollection"]
        StudentIterator["StudentIterator"]
    end

    subgraph Events["Event System"]
        EventMgr["EventManager"]
        Listener["AttendanceAlertListener"]
        GenListener["EventListener"]
    end

    AttendCtrl --> TemplateMethod
    TemplateMethod --> DataAccess
    DataAccess --> Support
    Support --> Events
    Events -->|triggers| Listener

    style TemplateMethod fill:#c8e6c9
    style DataAccess fill:#f1f8e9
    style Support fill:#ffecb3
    style Events fill:#f8bbd0
```

---

## Third-Party SMS Gateway Integration

```mermaid
graph LR
    subgraph Internal["Internal System"]
        NotifMgr["NotificationManager"]
        SMSStrat["SMSNotificationStrategy"]
    end

    subgraph Adapter["SMS Gateway Adapter\nAdapter Pattern"]
        SMSAdapter["SMSGatewayAdapter"]
        
        Translate["Message Translation"]
        Auth["Authentication\nManagement"]
        ErrorHandle["Error Handling"]
        Retry["Retry Logic"]
        
        SMSAdapter --> Translate
        SMSAdapter --> Auth
        SMSAdapter --> ErrorHandle
        SMSAdapter --> Retry
    end

    subgraph External["External SMS Gateway"]
        Gateway["Third-Party SMS Service\n(Twilio, Nexmo, etc.)]
        
        Config["Configuration"]
        RateLimit["Rate Limiting"]
        Logging["Delivery Logging"]
        
        Gateway --> Config
        Gateway --> RateLimit
        Gateway --> Logging
    end

    subgraph Devices["Target Devices"]
        SMS1["Student SMS"]
        SMS2["Teacher SMS"]
        SMS3["Parent SMS"]
    end

    NotifMgr --> SMSStrat
    SMSStrat -->|calls| SMSAdapter
    SMSAdapter -->|translates & sends| Gateway
    Gateway -->|delivers to| Devices

    style Adapter fill:#ffe0b2
    style External fill:#f0f4c3
    style Internal fill:#bbdefb
```

---

## Abstract Factory Pattern - User Accounts

```mermaid
graph TB
    subgraph Factory["Abstract Factory\nUser Account Creation"]
        Factory["UserAccountFactory\nInterface"]
        
        subgraph StudentFactory["StudentAccountFactory"]
            SF["StudentAccountFactory"]
            SP["createProfile()"]
            SPerm["createPermissions()"]
            SNotif["createNotificationPrefs()"]
            
            SF --> SP
            SF --> SPerm
            SF --> SNotif
        end
        
        subgraph TeacherFactory["TeacherAccountFactory"]
            TF["TeacherAccountFactory"]
            TP["createProfile()"]
            TPerm["createPermissions()"]
            TNotif["createNotificationPrefs()"]
            
            TF --> TP
            TF --> TPerm
            TF --> TNotif
        end
        
        Factory -->|implements| StudentFactory
        Factory -->|implements| TeacherFactory
    end

    subgraph StudentFamily["Student Account Family"]
        StudentProf["StudentProfile"]
        StudentPerm["StudentPermissions\n- View Grades\n- Submit Assignments"]
        StudentNotif["StudentNotificationPrefs\n- Grade Alerts\n- Assignment Due"]
    end

    subgraph TeacherFamily["Teacher Account Family"]
        TeacherProf["TeacherProfile"]
        TeacherPerm["TeacherPermissions\n- Create Course\n- Grade Students"]
        TeacherNotif["TeacherNotificationPrefs\n- Student Submissions\n- Attendance"]
    end

    SP -->|creates| StudentProf
    SPerm -->|creates| StudentPerm
    SNotif -->|creates| StudentNotif

    TP -->|creates| TeacherProf
    TPerm -->|creates| TeacherPerm
    TNotif -->|creates| TeacherNotif

    style Factory fill:#fff9c4
    style StudentFamily fill:#c8e6c9
    style TeacherFamily fill:#bbdefb
```

---

## Component Dependency Graph

```mermaid
graph TB
    UI["UI Layer"]
    
    NotifComp["Notification Component"]
    GradeComp["Grade Viewer Component"]
    AttendComp["Attendance Component"]
    
    Services["Service Layer"]
    Controllers["Controller Layer"]
    
    Data["Data Access Layer"]
    
    ThirdParty["Third-Party SMS Gateway"]
    
    UI --> Controllers
    Controllers --> Services
    Services --> NotifComp
    Services --> GradeComp
    Services --> AttendComp
    
    NotifComp --> Data
    GradeComp --> Data
    AttendComp --> Data
    
    NotifComp --> ThirdParty
    
    Data -->|writes to| DB["Database"]

    style NotifComp fill:#e1f5ff
    style GradeComp fill:#f3e5f5
    style AttendComp fill:#e8f5e9
    style ThirdParty fill:#ffe0b2
    style Data fill:#f1f8e9
    style Controllers fill:#ffecb3
    style Services fill:#f8bbd0
```

---

## Pattern Interaction Diagram

```mermaid
graph TB
    subgraph Patterns["Design Patterns Integration"]
        AF["Abstract Factory\nUI & User Families"]
        TM["Template Method\nWorkflow Orchestration"]
        Bridge["Bridge Pattern\nDecoupling Abstractions"]
        Strategy["Strategy Pattern\nAlgorithm Selection"]
        Adapter["Adapter Pattern\nThird-Party Integration"]
    end

    AF -->|creates| DocFamily["Document Families\n(PDF/Word)"]
    AF -->|creates| UserFamily["User Families\n(Student/Teacher)"]
    
    TM -->|defines| AttendWF["Attendance Workflow\n(Manual/QR)"]
    TM -->|defines| CourseWF["Course Workflow\n(Online/Offline)"]
    
    Bridge -->|separates| NotifAbst["Notification Types"]
    Bridge -->|separates| NotifImpl["Notification Senders"]
    
    Strategy -->|selects| ExportStrat["Export Format\n(CSV/PDF/Text)"]
    Strategy -->|selects| DeliveryStrat["Delivery Method\n(Email/SMS/InApp)"]
    
    Adapter -->|integrates| SMSGateway["External SMS\nGateway"]
    
    style AF fill:#fff9c4
    style TM fill:#c8e6c9
    style Bridge fill:#c8e6c9
    style Strategy fill:#bbdefb
    style Adapter fill:#ffe0b2
```

