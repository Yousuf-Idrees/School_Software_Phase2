package com.school.sms;

public class SMSGatewayDemo {
    
    public static void main(String[] args) {
        // Demonstrate Adapter Pattern for SMS Gateway
        System.out.println("=== SMS Gateway System using Adapter Pattern ===\n");
        
        // Create third-party SMS gateway (incompatible interface)
        ThirdPartySMSGateway gateway = new ThirdPartySMSGateway();
        
        // Adapt it to new interface using adapter
        NotificationSender adapter = new SMSGatewayAdapter(gateway);
        
        // Use through new interface
        NotificationService service = new NotificationService(adapter);
        
        // Send attendance alerts to different students
        service.sendAttendanceAlert("+201001234567", "Ahmed Kamal");
        service.sendAttendanceAlert("+201001234568", "Fatima Hassan");
        service.sendAttendanceAlert("+201001234569", "Mohamed Ali");
        
        System.out.println("\n=== SMS Gateway Demo Complete ===");
    }
}
