error id: file:///C:/Users/omars/Desktop/Soft/Software%20GUI/school%20software/school%20software/src/com/school/controller/SchoolController.java:com/school/services/GradeViewerService#
file:///C:/Users/omars/Desktop/Soft/Software%20GUI/school%20software/school%20software/src/com/school/controller/SchoolController.java
empty definition using pc, found symbol in pc: com/school/services/GradeViewerService#
empty definition using semanticdb
empty definition using fallback
non-local guesses:

offset: 97
uri: file:///C:/Users/omars/Desktop/Soft/Software%20GUI/school%20software/school%20software/src/com/school/controller/SchoolController.java
text:
```scala
package com.school.controller;

import com.school.data.StudentDAO;
import com.school.services.@@GradeViewerService;
import java.util.List;

public class SchoolController {
    private StudentDAO dataLayer = new StudentDAO();

    // Use Case 1: View Grades
    public String processGradeRequest(String id) {
        if (id.isEmpty()) return "Please enter an ID.";
        GradeViewerService.getInstance().viewGrades(id);
        List<String> grades = dataLayer.getGrades(id);
        return String.join("\n", grades);
    }
    public String getStudentInfo(String id) {
        return dataLayer.getStudentDetails(id);
    }
    // Use Case 2: View Attendance (Student)
    public String processAttendanceViewRequest(String id) {
        if (id.isEmpty()) return "Please enter an ID.";
        List<String> attendance = dataLayer.getAttendance(id);
        return String.join("\n", attendance);
    }
    public String login(String username, String password) {
        System.out.println("[CONTROLLER DEBUG] login called with: " + username);
        String role = dataLayer.verifyLogin(username, password);
        if (role != null) {
            System.out.println("[CONTROLLER DEBUG] Returning " + role);
            return role;
        }
        System.out.println("[CONTROLLER DEBUG] Returning INVALID");
        return "INVALID";
    }
    // Use Case 3: Record Attendance (Teacher) - THIS WAS MISSING
    public String processAttendanceRecord(String id, String status) {
        if (id.isEmpty()) return "Please enter a Student ID first.";

        // Get current date
        String date = java.time.LocalDate.now().toString();

        // Call DAO to save to database
        dataLayer.saveAttendance(id, date, status);

        return "Success: Recorded " + status + " for " + id + " on " + date;
    }
}
```


#### Short summary: 

empty definition using pc, found symbol in pc: com/school/services/GradeViewerService#