package com.school.services;

public interface IGradeExportService {
    String exportGradesToCSV(String studentId) throws Exception;
    
    String exportGradesToPDF(String studentId) throws Exception;
    
    String exportGradesToPlainText(String studentId) throws Exception;
    
    byte[] getExportedFileBytes(String studentId, String format) throws Exception;
}
