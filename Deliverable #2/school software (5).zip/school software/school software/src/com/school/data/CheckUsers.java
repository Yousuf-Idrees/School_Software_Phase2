package com.school.data;

import java.sql.*;

public class CheckUsers {
    public static void main(String[] args) {
        String dbUrl = "jdbc:sqlite:school.db";
        
        try (Connection conn = DriverManager.getConnection(dbUrl)) {
            System.out.println("Checking users in database...");
            System.out.println("======================================");
            
            String query = "SELECT id, username, password, role, name FROM users";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(query)) {
                
                while (rs.next()) {
                    System.out.println("ID: " + rs.getString("id"));
                    System.out.println("  Username: " + rs.getString("username"));
                    System.out.println("  Password: " + rs.getString("password"));
                    System.out.println("  Role: " + rs.getString("role"));
                    System.out.println("  Name: " + rs.getString("name"));
                    System.out.println();
                }
            }
            
            System.out.println("======================================");
            System.out.println("Try logging in with:");
            System.out.println("  Username: admin");
            System.out.println("  Password: teacher123");
            
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
