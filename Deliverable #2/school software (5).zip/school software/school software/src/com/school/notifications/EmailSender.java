package com.school.notifications;

/**
 * Concrete Implementor for Bridge Pattern
 * Sends exam notifications via email
 */
public class EmailSender implements NotificationSender {
    @Override
    public void sendMessage(String message) {
        System.out.println("Email: " + message);
    }
}
