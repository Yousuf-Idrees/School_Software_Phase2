package com.school.controller;

import com.school.services.IAttendanceMarkingService;
import com.school.services.AttendanceMarkingService;
import com.school.model.AttendanceRecord;
import com.school.data.AttendanceRepository;
import java.util.Map;
import java.util.HashMap;

public class AttendanceMarkingController {
    private IAttendanceMarkingService attendanceService;

    public AttendanceMarkingController(AttendanceRepository repository) {
        this.attendanceService = new AttendanceMarkingService(repository);
    }

    public AttendanceMarkingController(IAttendanceMarkingService service) {
        this.attendanceService = service;
    }

    public Map<String, Object> markAttendance(String studentId, String date, String presenceStatus) {
        Map<String, Object> response = new HashMap<>();
        try {
            AttendanceRecord record = attendanceService.markAttendance(studentId, date, presenceStatus);
            response.put("success", true);
            response.put("message", "Attendance marked successfully");
            response.put("data", record);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", "Bad Request");
            response.put("message", e.getMessage());
        }
        return response;
    }

    public Map<String, Object> updateAttendance(String recordId, String studentId, String date, String presenceStatus) {
        Map<String, Object> response = new HashMap<>();
        try {
            AttendanceRecord record = attendanceService.updateAttendance(recordId, studentId, date, presenceStatus);
            response.put("success", true);
            response.put("message", "Attendance record updated successfully");
            response.put("data", record);
        } catch (Exception e) {
            response.put("success", false);
            if (e.getMessage().contains("No attendance record found")) {
                response.put("error", "Not Found");
            } else {
                response.put("error", "Bad Request");
            }
            response.put("message", e.getMessage());
        }
        return response;
    }

    public Map<String, Object> deleteAttendance(String recordId) {
        Map<String, Object> response = new HashMap<>();
        try {
            attendanceService.deleteAttendance(recordId);
            response.put("success", true);
            response.put("message", "Attendance record deleted successfully");
            response.put("deletedId", recordId);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", "Not Found");
            response.put("message", e.getMessage());
        }
        return response;
    }

    public Map<String, Object> getAttendance(String recordId) {
        Map<String, Object> response = new HashMap<>();
        try {
            AttendanceRecord record = attendanceService.getAttendanceRecord(recordId);
            response.put("success", true);
            response.put("data", record);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", "Not Found");
            response.put("message", e.getMessage());
        }
        return response;
    }

    public void setAttendanceService(IAttendanceMarkingService service) {
        this.attendanceService = service;
    }
}
