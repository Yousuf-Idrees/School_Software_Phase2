package com.school.data;

public class TestDatabase {
    public static void main(String[] args) {
        System.out.println("Initializing database...");
        DatabaseConnection.initializeDatabase();
        
        System.out.println("Populating initial data...");
        DatabaseConnection.populateInitialData();
        
        System.out.println("[SUCCESS] Database setup complete!");
        System.out.println("Database file: school.db");
    }
}
