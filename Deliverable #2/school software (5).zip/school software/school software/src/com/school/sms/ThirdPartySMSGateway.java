package com.school.sms;

public class ThirdPartySMSGateway {
    public void dispatch(String phoneNumber, String body) {
        System.out.println("[SMS Gateway] Sending to " + phoneNumber + ": " + body);
    }
}
