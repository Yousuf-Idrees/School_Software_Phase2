package com.school.model;

public interface INotificationSender {
    void send(String recipient, String message) throws Exception;
    
    boolean validate(String recipient);
}
