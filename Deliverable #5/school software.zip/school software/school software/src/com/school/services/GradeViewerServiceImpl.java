package com.school.services;

import com.school.data.UserRepository;
import java.util.List;
import java.util.ArrayList;

public class GradeViewerServiceImpl implements IGradeViewerService {
    private static GradeViewerServiceImpl instance;
    private UserRepository userRepository;

    private GradeViewerServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public static synchronized GradeViewerServiceImpl getInstance(UserRepository userRepository) {
        if (instance == null) {
            instance = new GradeViewerServiceImpl(userRepository);
        }
        return instance;
    }

    @Override
    public List<Object> viewGrades(String studentId) throws Exception {
        if (!validateStudentId(studentId)) {
            throw new Exception("Invalid student ID: " + studentId);
        }
        
        Object student = userRepository.findById(studentId);
        if (student == null) {
            throw new Exception("Student not found with ID: " + studentId);
        }
        
        return fetchStudentGrades(studentId);
    }

    @Override
    public Object getGradeByStudentAndCourse(String studentId, String courseId) throws Exception {
        if (!validateStudentId(studentId)) {
            throw new Exception("Invalid student ID: " + studentId);
        }
        if (courseId == null || courseId.trim().isEmpty()) {
            throw new Exception("Invalid course ID");
        }
        
        return fetchGradeForCourse(studentId, courseId);
    }

    @Override
    public boolean validateStudentId(String studentId) {
        return studentId != null && !studentId.trim().isEmpty() && studentId.matches("\\d+-\\d+");
    }

    @Override
    public List<Object> getAllGrades() throws Exception {
        return fetchAllGrades();
    }

    private List<Object> fetchStudentGrades(String studentId) {
        List<Object> grades = new ArrayList<>();
        try {
            Object studentData = userRepository.findById(studentId);
            if (studentData != null) {
                return new ArrayList<>();
            }
        } catch (Exception e) {
            return grades;
        }
        return grades;
    }

    private Object fetchGradeForCourse(String studentId, String courseId) {
        try {
            return userRepository.findById(studentId);
        } catch (Exception e) {
            return null;
        }
    }

    private List<Object> fetchAllGrades() {
        return new ArrayList<>();
    }
}
