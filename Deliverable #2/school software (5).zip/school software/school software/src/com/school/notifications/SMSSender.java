package com.school.notifications;

/**
 * Concrete Implementor for Bridge Pattern
 * Sends exam notifications via SMS
 */
public class SMSSender implements NotificationSender {
    @Override
    public void sendMessage(String message) {
        System.out.println("SMS: " + message);
    }
}
