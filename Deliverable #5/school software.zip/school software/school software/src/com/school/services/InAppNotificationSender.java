package com.school.services;

import com.school.model.INotificationSender;
import com.school.model.NotificationDeliveryStrategy;
import java.util.List;
import java.util.ArrayList;

public class InAppNotificationSender implements INotificationSender, NotificationDeliveryStrategy {
    private List<String> notifications;

    public InAppNotificationSender() {
        this.notifications = new java.util.ArrayList<>();
    }

    @Override
    public void send(String recipient, String message) throws Exception {
        if (!validate(recipient)) {
            throw new Exception("Invalid recipient for in-app notification: " + recipient);
        }
        storeNotification(recipient, message);
    }

    @Override
    public boolean validate(String recipient) {
        return recipient != null && !recipient.trim().isEmpty();
    }

    @Override
    public void sendNotification(String recipient, String message) {
        try {
            send(recipient, message);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void storeNotification(String recipient, String message) {
        String notification = String.format("[%s] To: %s | Message: %s", 
            new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date()),
            recipient, 
            message);
        notifications.add(notification);
    }

    public List<String> getNotifications() {
        return new java.util.ArrayList<>(notifications);
    }

    public void clearNotifications() {
        notifications.clear();
    }
}
