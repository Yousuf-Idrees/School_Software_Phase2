package com.school.announcements;

class DashboardAnnouncement implements Announcement {
    public void post(String message) { System.out.println("Dashboard: " + message); }
}

class EmailAnnouncement implements Announcement {
    public void post(String message) { System.out.println("Email: " + message); }
}

// REMOVED 'public' here because it's in the wrong file
class DashboardAnnouncementCreator extends AnnouncementCreator {
    public Announcement createAnnouncement() { return new DashboardAnnouncement(); }
}

// KEEP 'public' here ONLY if the file is named EmailAnnouncementCreator.java
public class EmailAnnouncementCreator extends AnnouncementCreator {
    public Announcement createAnnouncement() { return new EmailAnnouncement(); }
}