package com.school.services;

import com.school.model.AttendanceRecord;
import com.school.data.AttendanceRepository;
import java.util.UUID;

public class AttendanceMarkingService implements IAttendanceMarkingService {
    private AttendanceRepository repository;

    public AttendanceMarkingService(AttendanceRepository repository) {
        this.repository = repository;
    }

    @Override
    public AttendanceRecord markAttendance(String studentId, String date, String presenceStatus) throws Exception {
        validateAttendanceData(studentId, date, presenceStatus);
        
        String recordId = UUID.randomUUID().toString();
        AttendanceRecord record = new AttendanceRecord(recordId, studentId, date, presenceStatus);
        
        repository.save(record);
        return record;
    }

    @Override
    public AttendanceRecord updateAttendance(String recordId, String studentId, String date, String presenceStatus) throws Exception {
        validateAttendanceData(studentId, date, presenceStatus);
        
        AttendanceRecord existingRecord = repository.findById(recordId);
        if (existingRecord == null) {
            throw new Exception("No attendance record found with ID: " + recordId);
        }
        
        existingRecord.setStudentId(studentId);
        existingRecord.setDate(date);
        existingRecord.setPresenceStatus(presenceStatus);
        
        repository.update(existingRecord);
        return existingRecord;
    }

    @Override
    public boolean deleteAttendance(String recordId) throws Exception {
        AttendanceRecord existingRecord = repository.findById(recordId);
        if (existingRecord == null) {
            throw new Exception("No attendance record found with ID: " + recordId + " to delete");
        }
        
        repository.delete(recordId);
        return true;
    }

    @Override
    public AttendanceRecord getAttendanceRecord(String recordId) throws Exception {
        AttendanceRecord record = repository.findById(recordId);
        if (record == null) {
            throw new Exception("No attendance record found with ID: " + recordId);
        }
        return record;
    }

    @Override
    public void validateAttendanceData(String studentId, String date, String presenceStatus) throws Exception {
        if (studentId == null || studentId.trim().isEmpty()) {
            throw new Exception("Missing required field: studentId");
        }
        if (date == null || date.trim().isEmpty()) {
            throw new Exception("Missing required field: date");
        }
        if (presenceStatus == null || presenceStatus.trim().isEmpty()) {
            throw new Exception("Missing required field: presenceStatus");
        }
        
        if (!presenceStatus.equals("Present") && !presenceStatus.equals("Absent") && !presenceStatus.equals("Late")) {
            throw new Exception("Invalid presenceStatus. Must be: Present, Absent, or Late");
        }
    }
}
