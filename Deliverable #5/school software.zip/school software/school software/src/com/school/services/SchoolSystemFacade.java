package com.school.services;

import com.school.adapters.SMSGatewayAdapter;
import com.school.adapters.IExternalSMSService;
import com.school.controller.AttendanceMarkingController;
import com.school.data.AttendanceRepository;
import com.school.data.UserRepository;

public class SchoolSystemFacade {
    private INotificationManager notificationManager;
    private IGradeViewerService gradeViewerService;
    private IGradeExportService gradeExportService;
    private IAttendanceMarkingService attendanceService;
    private AttendanceMarkingController attendanceController;
    private UserRepository userRepository;
    private AttendanceRepository attendanceRepository;

    public SchoolSystemFacade(UserRepository userRepo, AttendanceRepository attRepo) {
        this.userRepository = userRepo;
        this.attendanceRepository = attRepo;
        initializeServices();
    }

    private void initializeServices() {
        this.notificationManager = new NotificationManagerImpl(userRepository);
        this.gradeViewerService = GradeViewerServiceImpl.getInstance(userRepository);
        this.gradeExportService = new GradeExportServiceImpl();
        this.attendanceService = new AttendanceMarkingService(attendanceRepository);
        this.attendanceController = new AttendanceMarkingController(attendanceService);
    }

    public void initializeSMSGateway(String apiKey, String endpoint) throws Exception {
        SMSGatewayAdapter smsAdapter = new SMSGatewayAdapter(apiKey, endpoint);
        notificationManager.registerNotificationStrategy("SMS", smsAdapter);
    }

    public void initializeEmailNotifications() throws Exception {
        EmailNotificationSender emailSender = new EmailNotificationSender();
        notificationManager.registerNotificationStrategy("EMAIL", emailSender);
    }

    public void initializeInAppNotifications() throws Exception {
        InAppNotificationSender inAppSender = new InAppNotificationSender();
        notificationManager.registerNotificationStrategy("INAPP", inAppSender);
    }

    public INotificationManager getNotificationManager() {
        return notificationManager;
    }

    public IGradeViewerService getGradeViewerService() {
        return gradeViewerService;
    }

    public IGradeExportService getGradeExportService() {
        return gradeExportService;
    }

    public IAttendanceMarkingService getAttendanceService() {
        return attendanceService;
    }

    public AttendanceMarkingController getAttendanceController() {
        return attendanceController;
    }

    public void sendNotificationToStudent(String studentId, String message, String channel) throws Exception {
        notificationManager.sendNotificationToStudent(studentId, message, channel);
    }

    public void sendAttendanceAlert(String studentId, String message) throws Exception {
        sendNotificationToStudent(studentId, message, "SMS");
    }
}
