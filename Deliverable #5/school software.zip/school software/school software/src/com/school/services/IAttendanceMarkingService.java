package com.school.services;

import com.school.model.AttendanceRecord;

public interface IAttendanceMarkingService {
    AttendanceRecord markAttendance(String studentId, String date, String presenceStatus) throws Exception;
    
    AttendanceRecord updateAttendance(String recordId, String studentId, String date, String presenceStatus) throws Exception;
    
    boolean deleteAttendance(String recordId) throws Exception;
    
    AttendanceRecord getAttendanceRecord(String recordId) throws Exception;
    
    void validateAttendanceData(String studentId, String date, String presenceStatus) throws Exception;
}
