package com.school.assignments;

/**
 * Concrete Implementor for Bridge Pattern
 * Stores assignments in cloud storage (e.g., AWS S3, Google Cloud)
 */
public class CloudStorage implements Storage {
    @Override
    public void store(String fileName) {
        System.out.println("Storing " + fileName + " in cloud storage");
    }
}
