package com.school.announcements;

public abstract class AnnouncementCreator {
    protected abstract Announcement createAnnouncement();
    
    public void deliverAnnouncement(String message) {
        Announcement announcement = createAnnouncement();
        announcement.post(message);
    }
}