# Development View - Component Diagram

## System Overview
The school software system is organized into modular components following SOLID principles and design patterns. The architecture supports extensibility through factory patterns, template methods, and adapter integration with third-party services.

---

## Core Components

### 1. Notification System Component
**Location:** `src/com/school/model/`

#### Interfaces & Dependencies
- **NotificationSender** (Bridge Pattern Implementor)
  - EmailSender
  - SMSSender
  - InAppNotificationStrategy
  
- **Notification** (Bridge Pattern Abstraction)
  - ExamNotification
    - MidtermNotification
    - FinalNotification
  - NotificationSystem
  - AnnouncementEventClient

#### Key Classes
- NotificationManager: Central coordinator for all notifications
- NotificationDeliveryStrategy: Strategy interface for delivery mechanisms
- ExamNotification, MidtermNotification, FinalNotification: Concrete notifications
- SMSAlertPanel, ExamNotificationPanel: UI components

#### External Dependencies
- SMSGatewayAdapter (connects to third-party SMS provider)
- EventManager (event-driven notifications)

---

### 2. Grade Viewer Component
**Location:** `src/com/school/services/`

#### Interfaces & Dependencies
- **GradeViewerService** (Singleton)
  - Retrieves grades from database
  - Manages grade access control

- **GradeExportStrategy** (Strategy Pattern)
  - CSVGradeExportStrategy
  - PDFGradeExportStrategy
  - PlainTextGradeExportStrategy

#### Controller Layer
- **GradeController**
  - Orchestrates grade operations
  - Delegates to GradeExporter

- **GradeExporter**
  - Central facade for grade operations
  - Uses GradeExporterContext with strategy pattern

#### Key Components
- GradeExporterContext: Strategy context
- ReportGenerator: Generates grade reports
- DocumentManager: Manages grade documents

#### Template Method Pattern
- ReportGenerationService: Abstract template for report generation
- Concrete implementations: Grade reports, attendance reports, course reports

---

### 3. Attendance Marking Component
**Location:** `src/com/school/controller/` and `src/com/school/model/`

#### Core Interfaces
- **AttendanceRepository** (Data Access)
  - Manages attendance records in database
  - CRUD operations for attendance

- **AttendanceMarkingService** (Service Layer)
  - Mark attendance for students
  - Update attendance records
  - Delete attendance records
  - Validate attendance data

- **AttendanceProcess** (Model)
  - QRAttendance: QR code-based marking
  - ManualAttendance: Manual attendance marking

#### Controller Layer
- **AttendanceController**
  - REST/UI interface for attendance operations
  - Delegates to AttendanceMarkingService

#### Template Method Implementation
- AttendanceProcess: Abstract template for attendance workflows
  - QRAttendance: QR code scanning workflow
  - ManualAttendance: Manual entry workflow

#### Linked Components
- AttendanceAlertListener: Alert notifications for absences
- EventManager: Event-based attendance updates

---

### 4. Abstract Factory - UI Families Component
**Location:** `src/com/school/accounts/`

#### Interfaces & Dependencies
- **UserAccountFactory** (Abstract Factory)
  - StudentAccountFactory
  - TeacherAccountFactory

- **UserProfile** (Created Family)
  - StudentProfile
  - TeacherProfile

- **UserPermissions** (Created Family)
  - StudentPermissions
  - TeacherPermissions

#### Related Classes
- UserManager: Manages user instances
- StudentUser, TeacherUser: Concrete user types

#### UI Integration
- LoginGUI: Uses factory to create appropriate user profiles
- UI components automatically adapt to user type

---

### 5. Third-Party SMS Gateway Component
**Location:** `src/com/school/adapters/` (New)

#### Adapter Pattern Implementation
- **SMSGatewayAdapter** (Adapter)
  - Adapts external SMS service to NotificationSender interface
  - Handles API authentication and message formatting

- **ExternalSMSService** (External API)
  - Third-party SMS provider
  - Sends actual SMS messages

#### Configuration
- Gateway credentials and endpoints
- Message rate limiting
- Fallback mechanisms

---

## Component Dependencies & Interfaces

### Dependency Graph
```
LoginGUI
  ├── UserAccountFactory (Abstract Factory)
  │   ├── StudentAccountFactory
  │   └── TeacherAccountFactory
  ├── AttendanceController
  │   └── AttendanceMarkingService
  │       ├── AttendanceRepository
  │       └── AttendanceAlertListener
  ├── GradeController
  │   └── GradeExporter (Strategy Pattern)
  │       ├── GradeExporterContext
  │       └── GradeExportStrategy implementations
  └── NotificationManager
      ├── NotificationSender (Bridge)
      │   ├── EmailSender
      │   ├── SMSSender
      │   └── SMSGatewayAdapter (Adapter)
      │       └── ExternalSMSService
      └── Notification (Bridge)
          ├── ExamNotification
          ├── NotificationSystem
          └── AnnouncementEventClient
```

---

## Pattern Usage Summary

| Component | Pattern | Purpose |
|-----------|---------|---------|
| Attendance Marking | Template Method | Define workflow steps for different attendance modes |
| Grade Viewer | Singleton + Strategy | Single instance with multiple export formats |
| Notification System | Bridge + Strategy | Decouple notification types from delivery channels |
| UI Families | Abstract Factory | Create user-type-specific UI and permissions |
| SMS Integration | Adapter | Connect third-party SMS service to internal interface |

---

## Interface Definitions

### NotificationSender (Bridge Implementor)
```
+ send(recipient: String, message: String): void
+ validate(recipient: String): boolean
```

### AttendanceMarkingService
```
+ markAttendance(studentId: String, date: String, status: String): AttendanceRecord
+ updateAttendance(recordId: String, studentId: String, date: String, status: String): AttendanceRecord
+ deleteAttendance(recordId: String): void
+ validateAttendanceData(studentId: String, date: String, status: String): boolean
```

### GradeExportStrategy
```
+ export(grades: List<Grade>): String
+ getFormat(): String
```

### SMSGatewayAdapter
```
+ send(recipient: String, message: String): void
+ validate(recipient: String): boolean
+ setCredentials(apiKey: String, endpoint: String): void
```

---

## Data Flow Examples

### Attendance Marking Flow
User (LoginGUI) → AttendanceController → AttendanceMarkingService → AttendanceRepository → Database
                                    ↓
                      AttendanceAlertListener → NotificationManager → NotificationSender (SMS/Email)

### Notification Delivery Flow
NotificationManager → Notification (Bridge Abstraction) → NotificationSender (Bridge Implementor)
                                                         → EmailSender
                                                         → SMSSender → SMSGatewayAdapter → ExternalSMSService

### Grade Export Flow
LoginGUI → GradeController → GradeExporter → GradeExporterContext → GradeExportStrategy
                                           → ReportGenerator → DocumentManager

---

## NFRs (Non-Functional Requirements) Addressed

1. **Modularity**: Components are independent with clear interfaces
2. **Extensibility**: New notification channels, export formats, and attendance modes can be added without modifying existing code
3. **Maintainability**: Design patterns provide clear separation of concerns
4. **Scalability**: Service layer supports increased load
5. **Reliability**: Adapter pattern isolates third-party service failures
6. **Reusability**: Factory pattern enables UI family reuse across user types
