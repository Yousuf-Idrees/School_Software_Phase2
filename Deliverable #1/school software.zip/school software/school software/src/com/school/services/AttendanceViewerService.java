package com.school.services;

public class AttendanceViewerService {
    private static volatile AttendanceViewerService instance;
    private AttendanceViewerService() {}

    public static AttendanceViewerService getInstance() {
        if (instance == null) {
            synchronized (AttendanceViewerService.class) {
                if (instance == null) {
                    instance = new AttendanceViewerService();
                }
            }
        }
        return instance;
    }

    public void viewAttendance(String studentId, String date) { 
        System.out.println("Attendance for " + studentId + " on " + date + ": Present");
    }
}