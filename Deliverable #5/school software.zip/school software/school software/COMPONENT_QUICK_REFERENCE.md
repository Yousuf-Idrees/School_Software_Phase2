# Development View - Component Reference & Quick Start

## Component Summary

### Core Components Implemented

| Component | Type | Location | Pattern | Status |
|-----------|------|----------|---------|--------|
| AttendanceRecord | Model | model/ | Data Model | ✅ |
| IAttendanceMarkingService | Interface | services/ | Service Layer | ✅ |
| AttendanceMarkingService | Implementation | services/ | Template Method | ✅ |
| AttendanceMarkingController | Controller | controller/ | Adapter Pattern | ✅ |
| INotificationSender | Interface | model/ | Bridge | ✅ |
| INotificationManager | Interface | services/ | Strategy | ✅ |
| NotificationManagerImpl | Implementation | services/ | Coordinator | ✅ |
| EmailNotificationSender | Implementation | services/ | Strategy | ✅ |
| InAppNotificationSender | Implementation | services/ | Strategy | ✅ |
| SMSGatewayAdapter | Adapter | adapters/ | Adapter Pattern | ✅ |
| ExternalSMSServiceImpl | Implementation | adapters/ | External Service | ✅ |
| IGradeViewerService | Interface | services/ | Singleton | ✅ |
| GradeViewerServiceImpl | Implementation | services/ | Singleton | ✅ |
| IGradeExportService | Interface | services/ | Strategy | ✅ |
| GradeExportServiceImpl | Implementation | services/ | Strategy | ✅ |
| SchoolSystemFacade | Facade | services/ | Facade | ✅ |

---

## Quick Start - Integration Points

### 1. Initialize the System Facade
```java
UserRepository userRepo = // Initialize from database
AttendanceRepository attRepo = // Initialize from database

SchoolSystemFacade system = new SchoolSystemFacade(userRepo, attRepo);
```

### 2. Configure Notification Channels
```java
system.initializeEmailNotifications();
system.initializeInAppNotifications();
system.initializeSMSGateway("your-api-key", "https://api.sms-provider.com/send");
```

### 3. Mark Attendance
```java
AttendanceMarkingController controller = system.getAttendanceController();
Map<String, Object> result = controller.markAttendance(
    "STU-123",
    "2026-05-16",
    "Present"
);
```

### 4. Send Notifications
```java
system.sendNotificationToStudent(
    "STU-123",
    "Attendance marked successfully",
    "SMS"
);
```

### 5. View & Export Grades
```java
IGradeViewerService gradeService = system.getGradeViewerService();
List<Object> grades = gradeService.viewGrades("STU-123");

IGradeExportService exportService = system.getGradeExportService();
byte[] pdfData = exportService.getExportedFileBytes("STU-123", "pdf");
```

---

## Component Dependency Hierarchy

```
┌─────────────────────────────────────────────────────┐
│         SchoolSystemFacade (Coordinator)            │
├─────────────────────────────────────────────────────┤
│                                                     │
├─ INotificationManager                              │
│  ├─ NotificationManagerImpl                         │
│  │  ├─ INotificationSender (Strategy)              │
│  │  │  ├─ EmailNotificationSender                  │
│  │  │  ├─ InAppNotificationSender                  │
│  │  │  └─ SMSGatewayAdapter (Bridge/Adapter)      │
│  │  │     └─ ExternalSMSService (Third-Party)    │
│  │  └─ UserRepository                             │
│                                                     │
├─ IGradeViewerService                               │
│  ├─ GradeViewerServiceImpl (Singleton)              │
│  └─ UserRepository                                 │
│                                                     │
├─ IGradeExportService                               │
│  ├─ GradeExportServiceImpl                          │
│  │  ├─ CSVGradeExportStrategy                      │
│  │  ├─ PDFGradeExportStrategy                      │
│  │  └─ PlainTextGradeExportStrategy                │
│  └─ GradeExporter (Context)                        │
│                                                     │
├─ IAttendanceMarkingService                         │
│  ├─ AttendanceMarkingService                       │
│  └─ AttendanceRepository                           │
│                                                     │
└─ AttendanceMarkingController                       │
   └─ AttendanceMarkingService                       │
                                                     │
└─────────────────────────────────────────────────────┘
```

---

## File Structure

```
src/com/school/
├── model/
│   ├── AttendanceRecord.java
│   ├── INotificationSender.java
│   ├── NotificationDeliveryStrategy.java (existing)
│   └── ... (other existing models)
│
├── services/
│   ├── IAttendanceMarkingService.java
│   ├── AttendanceMarkingService.java
│   ├── INotificationManager.java
│   ├── NotificationManagerImpl.java
│   ├── EmailNotificationSender.java
│   ├── InAppNotificationSender.java
│   ├── IGradeViewerService.java
│   ├── GradeViewerServiceImpl.java
│   ├── IGradeExportService.java
│   ├── GradeExportServiceImpl.java
│   ├── SchoolSystemFacade.java
│   └── ... (other existing services)
│
├── adapters/
│   ├── IExternalSMSService.java
│   ├── ExternalSMSServiceImpl.java
│   └── SMSGatewayAdapter.java
│
├── controller/
│   ├── AttendanceMarkingController.java
│   └── ... (other existing controllers)
│
└── ... (other existing packages)
```

---

## Pattern Justifications (NFRs)

### Template Method Pattern (Attendance Workflow)
**Justification:**
- Defines skeleton of attendance marking algorithm
- Allows different implementations (QR, Manual) without modifying core logic
- Ensures consistent workflow across all attendance types
- Easy to add new attendance modes (Biometric, RFID, etc.)

**NFR Addressed:** Extensibility, Maintainability

### Strategy Pattern (Grade Export)
**Justification:**
- Encapsulates multiple export algorithms (CSV, PDF, Text)
- Runtime algorithm selection without conditional logic
- Easy to add new export formats without modifying existing code
- Follows Open/Closed Principle

**NFR Addressed:** Extensibility, Flexibility

### Singleton Pattern (Grade Viewer)
**Justification:**
- Ensures single instance manages all grade database access
- Reduces redundant database connections
- Thread-safe access to shared resource
- Centralizes grade access control

**NFR Addressed:** Performance, Reliability, Single Responsibility

### Bridge Pattern (Notification Delivery)
**Justification:**
- Decouples notification types from delivery mechanisms
- Mix-and-match notification types with delivery channels
- Easy to add new channels (Push, Slack) without modifying existing notifications
- Independent evolution of abstractions and implementations

**NFR Addressed:** Modularity, Extensibility, Loose Coupling

### Adapter Pattern (SMS Gateway)
**Justification:**
- Adapts third-party SMS service to internal interface
- Isolates external dependency from core system
- Easy to switch SMS providers without code changes
- Prevents vendor lock-in

**NFR Addressed:** Modularity, Flexibility, Maintainability

### Facade Pattern (SchoolSystemFacade)
**Justification:**
- Provides unified interface to complex subsystems
- Simplifies client code interaction with system
- Centralizes initialization and configuration
- Reduces coupling between client and components

**NFR Addressed:** Usability, Maintainability, Abstraction

### Abstract Factory Pattern (User Account Factory - existing)
**Justification:**
- Creates families of related objects (profiles, permissions) per user type
- UI adapts automatically based on factory selection
- Consistent object creation across application
- Easy to add new user types

**NFR Addressed:** Modularity, Consistency, Extensibility

---

## Error Response Formats

### Success Response (Attendance Operations)
```json
{
  "success": true,
  "message": "Attendance marked successfully",
  "data": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "studentId": "STU-123",
    "date": "2026-05-16",
    "presenceStatus": "Present"
  }
}
```

### Error Response (Validation)
```json
{
  "success": false,
  "error": "Bad Request",
  "message": "Missing required field: presenceStatus"
}
```

### Error Response (Not Found)
```json
{
  "success": false,
  "error": "Not Found",
  "message": "No attendance record found with ID: invalid-id"
}
```

---

## External Dependencies

### For SMS Gateway
- External SMS Provider API (configurable endpoint)
- HTTP client for API communication
- API authentication credentials

### For Email Notifications
- SMTP server configuration
- Email credentials

### For Database
- UserRepository implementation
- AttendanceRepository implementation

### For Existing Components
- UserAccountFactory (Abstract Factory)
- AttendanceProcess implementations
- Classroom and Seat management (Flyweight)
- EventManager and EventListener

---

## Testing Checklist

### Unit Tests
- [ ] AttendanceRecord model creation and getters/setters
- [ ] AttendanceMarkingService validation logic
- [ ] NotificationManager strategy registration and selection
- [ ] SMSGatewayAdapter phone number validation
- [ ] GradeViewerService singleton instance uniqueness
- [ ] GradeExportService format selection

### Integration Tests
- [ ] Attendance marking → Alert notification flow
- [ ] Grade viewing → Export flow
- [ ] Multiple notification channels delivery
- [ ] SMS adapter → External service communication

### Error Handling Tests
- [ ] Missing field validation
- [ ] Invalid record ID handling
- [ ] Network failure graceful degradation
- [ ] Duplicate registration attempts

---

## Performance Considerations

1. **Singleton Pattern Benefits**
   - Single database connection pool
   - Reduced memory overhead
   - Thread-safe access to grades

2. **Strategy Pattern Benefits**
   - No runtime type checking
   - Lazy loading of export strategies
   - Independent algorithm optimization

3. **Adapter Pattern Benefits**
   - Minimal transformation overhead
   - External service caching capability
   - Rate limiting implementation point

4. **Facade Pattern Benefits**
   - Reduced object creation overhead
   - Service initialization optimization
   - Connection pooling coordination

---

## Security Considerations

### Input Validation
- All student IDs validated against format
- Attendance status restricted to enum values
- Phone numbers normalized before processing
- Messages escaped for JSON injection prevention

### Third-Party Integration
- API credentials externalized (not hardcoded)
- HTTPS enforced for external communication
- Rate limiting recommended at adapter level
- Audit logging for all external calls

### Data Access
- Single repository interface for consistency
- Access control points defined (but not implemented)
- Database connection security delegated to repository

