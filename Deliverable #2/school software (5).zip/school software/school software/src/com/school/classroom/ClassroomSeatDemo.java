package com.school.classroom;

/**
 * Demo class for Classroom Seat Management (Flyweight Pattern)
 * Demonstrates efficient memory usage through object reuse
 */
public class ClassroomSeatDemo {
    public static void main(String[] args) {
        System.out.println("===== Classroom Seat Management Demo (Flyweight Pattern) =====\n");

        // Create classroom with 30 seats
        Classroom classroom1 = new Classroom("Room 101", 30);
        System.out.println();

        // Create another classroom with 25 seats
        Classroom classroom2 = new Classroom("Room 102", 25);
        System.out.println();

        // Assign students to seats in first classroom
        System.out.println("\n--- Assigning students to Room 101 ---");
        classroom1.assignStudentToSeat(1, "Alice Johnson");
        classroom1.assignStudentToSeat(5, "Bob Smith");
        classroom1.assignStudentToSeat(10, "Carol White");

        // Assign students to seats in second classroom
        System.out.println();
        System.out.println("--- Assigning students to Room 102 ---");
        classroom2.assignStudentToSeat(3, "David Brown");
        classroom2.assignStudentToSeat(7, "Eve Davis");

        // Display classroom layouts
        classroom1.displayClassroomLayout();
        System.out.println();
        classroom2.displayClassroomLayout();

        System.out.println("\n===== Flyweight Pattern Benefits =====");
        System.out.println("1. Memory efficient: Shared seat type objects reduce memory usage");
        System.out.println("2. With 55 seats total, only ONE 'Standard' SeatType object is created");
        System.out.println("3. Easy to add new seat types (Premium, Accessible, etc.)");
        System.out.println("4. Extrinsic state (seat number, student) is managed per seat");
    }
}
