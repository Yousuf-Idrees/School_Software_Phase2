package com.school.services;

import com.school.model.INotificationSender;
import com.school.data.UserRepository;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;

public class NotificationManagerImpl implements INotificationManager {
    private Map<String, INotificationSender> strategies;
    private String defaultStrategy;
    private UserRepository userRepository;

    public NotificationManagerImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
        this.strategies = new HashMap<>();
    }

    @Override
    public void sendNotificationToStudent(String studentId, String message, String notificationType) throws Exception {
        if (!validateStudentId(studentId)) {
            throw new Exception("Invalid student ID: " + studentId);
        }
        if (message == null || message.trim().isEmpty()) {
            throw new Exception("Message cannot be empty");
        }

        String strategyToUse = notificationType != null && strategies.containsKey(notificationType) 
            ? notificationType 
            : defaultStrategy;

        if (strategyToUse == null || !strategies.containsKey(strategyToUse)) {
            throw new Exception("No notification strategy available");
        }

        INotificationSender sender = strategies.get(strategyToUse);
        sender.send(studentId, message);
    }

    @Override
    public void sendNotificationToStudents(List<String> studentIds, String message, String notificationType) throws Exception {
        if (studentIds == null || studentIds.isEmpty()) {
            throw new Exception("Student ID list cannot be empty");
        }
        if (message == null || message.trim().isEmpty()) {
            throw new Exception("Message cannot be empty");
        }

        for (String studentId : studentIds) {
            try {
                sendNotificationToStudent(studentId, message, notificationType);
            } catch (Exception e) {
                System.err.println("Failed to send notification to " + studentId + ": " + e.getMessage());
            }
        }
    }

    @Override
    public void registerNotificationStrategy(String strategyName, INotificationSender sender) throws Exception {
        if (strategyName == null || strategyName.trim().isEmpty()) {
            throw new Exception("Strategy name cannot be empty");
        }
        if (sender == null) {
            throw new Exception("Sender cannot be null");
        }

        strategies.put(strategyName, sender);
        
        if (defaultStrategy == null) {
            defaultStrategy = strategyName;
        }
    }

    @Override
    public void setDefaultStrategy(String strategyName) throws Exception {
        if (!strategies.containsKey(strategyName)) {
            throw new Exception("Strategy not found: " + strategyName);
        }
        defaultStrategy = strategyName;
    }

    @Override
    public List<String> getAvailableStrategies() {
        return new ArrayList<>(strategies.keySet());
    }

    @Override
    public boolean validateStudentId(String studentId) {
        return studentId != null && !studentId.trim().isEmpty();
    }
}
