package com.school.grades;

public class GradeExportDemo {
    
    public static void main(String[] args) {
        // Demonstrate Adapter Pattern for Grade Export
        System.out.println("=== Grade Export System using Adapter Pattern ===\n");
        
        // Create legacy report printer (incompatible interface)
        LegacyReportPrinter legacyPrinter = new LegacyReportPrinter();
        
        // Adapt it to new interface using adapter
        GradeExporter adapter = new GradeExporterAdapter(legacyPrinter);
        
        // Use through new interface
        ReportService service = new ReportService(adapter);
        
        // Generate reports for different students
        service.generateReport("23-101091", "Math: A+, English: A, Science: B+");
        service.generateReport("23-101296", "Math: B, English: A, Science: A-");
        service.generateReport("23-101077", "Math: A, English: B+, Science: A");
        
        System.out.println("\n=== Grade Export Demo Complete ===");
    }
}
