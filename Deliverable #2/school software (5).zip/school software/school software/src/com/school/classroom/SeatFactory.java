package com.school.classroom;

import java.util.HashMap;

/**
 * Flyweight Factory for Classroom Seat Management
 * Manages and reuses seat type objects to reduce memory consumption
 * Implements the Flyweight design pattern
 */
public class SeatFactory {
    private static HashMap<String, SeatType> seats = new HashMap<>();

    /**
     * Gets or creates a seat type
     * If the type already exists, returns the cached instance
     * Otherwise, creates a new instance and caches it
     */
    public static SeatType getSeatType(String type) {
        if (!seats.containsKey(type)) {
            seats.put(type, new SeatType(type));
            System.out.println("Creating new seat type: " + type);
        } else {
            System.out.println("Reusing existing seat type: " + type);
        }
        return seats.get(type);
    }

    /**
     * Returns the number of cached seat types
     */
    public static int getCacheSize() {
        return seats.size();
    }

    /**
     * Clears all cached seat types
     */
    public static void clearCache() {
        seats.clear();
    }
}
