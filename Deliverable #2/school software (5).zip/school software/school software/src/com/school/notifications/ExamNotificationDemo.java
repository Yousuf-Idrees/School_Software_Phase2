package com.school.notifications;

/**
 * Demo class for Exam Notification System (Bridge Pattern)
 * Demonstrates flexible combination of exam types and notification mechanisms
 */
public class ExamNotificationDemo {
    public static void main(String[] args) {
        System.out.println("===== Exam Notification System Demo (Bridge Pattern) =====\n");

        // Create notification senders
        NotificationSender emailSender = new EmailSender();
        NotificationSender smsSender = new SMSSender();

        // Create midterm notifications with different sending mechanisms
        System.out.println("--- Midterm Notifications ---");
        ExamNotification midtermEmail = new MidtermNotification(emailSender);
        midtermEmail.notifyStudent();

        System.out.println();

        ExamNotification midtermSMS = new MidtermNotification(smsSender);
        midtermSMS.notifyStudent();

        System.out.println();

        // Create final notifications with different sending mechanisms
        System.out.println("--- Final Exam Notifications ---");
        ExamNotification finalEmail = new FinalNotification(emailSender);
        finalEmail.notifyStudent();

        System.out.println();

        ExamNotification finalSMS = new FinalNotification(smsSender);
        finalSMS.notifyStudent();

        System.out.println("\n===== Bridge Pattern Benefits =====");
        System.out.println("1. Decouples exam notification types from sending mechanisms");
        System.out.println("2. Easy to add new notification types (Quiz, Practical, etc.)");
        System.out.println("3. Easy to add new senders (Push notification, Slack, etc.)");
    }
}
