error id: file:///C:/Users/omars/Desktop/Soft/Software%20GUI/school%20software/school%20software/src/com/school/controller/GradeController.java:com/school/data/StudentDAO#
file:///C:/Users/omars/Desktop/Soft/Software%20GUI/school%20software/school%20software/src/com/school/controller/GradeController.java
empty definition using pc, found symbol in pc: com/school/data/StudentDAO#
empty definition using semanticdb
empty definition using fallback
non-local guesses:

offset: 57
uri: file:///C:/Users/omars/Desktop/Soft/Software%20GUI/school%20software/school%20software/src/com/school/controller/GradeController.java
text:
```scala
package com.school.controller;

import com.school.data.@@StudentDAO;
import java.util.List;

public class GradeController {
    private StudentDAO studentDAO = new StudentDAO();

    public List<String> viewStudentGrades(String studentID) {
        // Validation logic can go here (e.g., checking if ID is empty)
        if (studentID == null || studentID.isEmpty()) {
            return null;
        }
        return studentDAO.getGrades(studentID);
    }
}
```


#### Short summary: 

empty definition using pc, found symbol in pc: com/school/data/StudentDAO#