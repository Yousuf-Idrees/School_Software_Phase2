package com.school.assignments;

/**
 * Demo class for Assignment Submission System (Bridge Pattern)
 * Demonstrates flexible combination of assignment types and storage mechanisms
 */
public class AssignmentDemo {
    public static void main(String[] args) {
        System.out.println("===== Assignment Submission System Demo (Bridge Pattern) =====\n");

        // Create storage implementations
        Storage localStorage = new LocalStorage();
        Storage cloudStorage = new CloudStorage();

        // Create homework assignments with different storage options
        System.out.println("--- Homework Assignments ---");
        Assignment homework1 = new Homework(localStorage);
        homework1.submit("math_homework.pdf");

        System.out.println();

        Assignment homework2 = new Homework(cloudStorage);
        homework2.submit("english_homework.docx");

        System.out.println();

        // Create project assignments with different storage options
        System.out.println("--- Project Assignments ---");
        Assignment project1 = new Project(localStorage);
        project1.submit("science_project.zip");

        System.out.println();

        Assignment project2 = new Project(cloudStorage);
        project2.submit("history_project.pdf");

        System.out.println("\n===== Bridge Pattern Benefits =====");
        System.out.println("1. Decouples assignment types from storage implementations");
        System.out.println("2. Easy to add new storage types without modifying existing code");
        System.out.println("3. Easy to add new assignment types independently");
    }
}
