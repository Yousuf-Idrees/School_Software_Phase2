package com.school.assignments;

/**
 * Concrete Implementor for Bridge Pattern
 * Stores assignments locally on the server
 */
public class LocalStorage implements Storage {
    @Override
    public void store(String fileName) {
        System.out.println("Storing " + fileName + " locally on server");
    }
}
