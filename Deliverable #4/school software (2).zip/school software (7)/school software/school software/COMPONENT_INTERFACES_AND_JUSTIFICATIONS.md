# Component Interface Reference & Pattern Justifications

## Executive Summary for Sayed

This document provides the interface specifications and design pattern justifications for the three core modular components and their third-party integrations.

---

## 1. NOTIFICATION SYSTEM COMPONENT

### Component Purpose
Manages all notification delivery across the system with support for multiple delivery channels (Email, SMS, In-App) and notification types (Announcements, Exam Alerts, Attendance Alerts).

### Public Interfaces

#### 1.1 Notification Delivery Strategy Interface
```
Interface: NotificationDeliveryStrategy
Methods:
├── sendNotification(String recipient, String message): void
├── validateRecipient(String recipient): boolean
└── getDeliveryStatus(String messageId): DeliveryStatus
```

**Implementations**:
- `EmailNotificationStrategy` - Send via email
- `SMSNotificationStrategy` - Send via SMS Gateway Adapter
- `InAppNotificationStrategy` - Send to dashboard

#### 1.2 Notification Manager Interface
```
Interface: NotificationManager
Methods:
├── sendNotification(Notification notification, NotificationDeliveryStrategy strategy): void
├── scheduleNotification(Notification notification, DateTime time): void
├── cancelNotification(String notificationId): void
└── getNotificationHistory(String userId): List<Notification>
```

#### 1.3 Notification System Interface
```
Interface: NotificationSystem
Methods:
├── registerListener(EventListener listener): void
├── unregisterListener(EventListener listener): void
├── publishEvent(Event event): void
└── getEventHistory(): List<Event>
```

### Pattern Justifications

#### Pattern 1: Strategy Pattern (NotificationDeliveryStrategy)
**Justification**:
- Different delivery methods (Email, SMS, In-App) have different algorithms
- Need to select delivery method at runtime based on user preferences
- New delivery channels (Push, Teams, Slack) can be added without modifying existing code
- Context (NotificationManager) holds a strategy and delegates to it

**Benefits**:
- Open/Closed Principle: Open for extension (new strategies), closed for modification
- Single Responsibility: Each strategy handles one delivery method
- Eliminates if-else chains that select delivery method

#### Pattern 2: Decorator Pattern (NotificationDecorator)
**Justification**:
- Multiple notification delivery channels can be applied to the same notification
- Example: Send notification to both Email AND SMS (combining decorators)
- Behavior should be added dynamically without creating new subclasses
- Alternative to inheritance which would create class explosion

**Benefits**:
- Flexible: Any combination of decorators can be applied
- Maintainable: Each decorator is independent
- Runtime: Decorators can be applied at runtime

#### Pattern 3: Bridge Pattern (ExamNotification ↔ NotificationSender)
**Justification**:
- Exam notifications (abstraction) are independent of delivery methods (implementation)
- MidtermNotification and FinalNotification can use any sender
- Adding new notification types doesn't require changing senders
- Adding new senders doesn't require changing notification types
- Prevents dimension explosion (N notification types × M senders)

**Benefits**:
- Abstraction and implementation can evolve independently
- No coupling between notification types and delivery mechanisms
- Easy to add new notification types (Midterm, Final, Pop-Quiz)
- Easy to add new senders (Email, SMS, Push)

#### Pattern 4: Observer Pattern (EventListener)
**Justification**:
- Attendance events trigger notifications automatically
- Multiple listeners can react to the same event
- Loose coupling: Event source doesn't need to know all listeners
- Enables event-driven architecture

**Benefits**:
- Event producers don't know about consumers
- Multiple listeners can handle same event
- New listeners can be added without modifying source

### External Dependencies

**Data Access**:
- `NotificationRepository` - Stores notification history
- `UserRepository` - Retrieves user contact information

**Third-Party Integration**:
- `SMSGatewayAdapter` - Connects to external SMS service (Twilio, Nexmo)

**UI Components**:
- `SMSAlertPanel` - Displays SMS alerts
- `ExamNotificationPanel` - Displays exam notifications
- `AnnouncementPanel` - Displays announcements

---

## 2. GRADE VIEWER COMPONENT

### Component Purpose
Provides grade viewing, exporting in multiple formats, and generating reports for students and teachers.

### Public Interfaces

#### 2.1 Grade Viewer Service Interface
```
Interface: GradeViewerService (Singleton)
Methods:
├── getInstance(): GradeViewerService
├── viewGrades(String studentId): List<Grade>
├── viewCourseGrades(String studentId, String courseId): List<Grade>
├── getGradeStatistics(String studentId): GradeStatistics
└── exportGrades(String studentId, GradeExportStrategy strategy): File
```

**Characteristics**:
- Thread-safe singleton
- Ensures only one instance manages all grade access
- Resource efficient for database connections

#### 2.2 Grade Export Strategy Interface
```
Interface: GradeExportStrategy
Methods:
├── exportGrades(String studentId, List<String> gradeLines): void
├── getFileExtension(): String
├── validateFormat(): boolean
└── getFormatDescription(): String
```

**Implementations**:
- `CSVGradeExportStrategy` - Export to CSV format
- `PDFGradeExportStrategy` - Export to PDF format (uses DocumentFactory)
- `PlainTextGradeExportStrategy` - Export to text format

#### 2.3 Report Generation Service Interface
```
Interface: ReportGenerationService
Methods:
├── generateStudentReport(String studentId): Report
├── generateClassReport(String classId): Report
├── generateDetailedReport(String studentId, String courseId): Report
└── scheduleReportGeneration(String studentId, DateTime time): void
```

#### 2.4 Grade Exporter Context Interface
```
Interface: GradeExporterContext
Methods:
├── setExportStrategy(GradeExportStrategy strategy): void
├── executeExport(String studentId): File
├── getAvailableStrategies(): List<GradeExportStrategy>
└── validateExportParameters(): boolean
```

### Pattern Justifications

#### Pattern 1: Singleton Pattern (GradeViewerService)
**Justification**:
- Only one grade viewer service should exist (expensive database resource)
- Need global point of access to grade data
- Prevents multiple instances competing for database connections
- Thread-safe initialization ensures consistency in multi-threaded environment

**Benefits**:
- Controlled resource access
- Memory efficient
- Ensures data consistency
- Global point of access

#### Pattern 2: Strategy Pattern (GradeExportStrategy)
**Justification**:
- Different export formats (CSV, PDF, Text) have different algorithms
- Need to select format at runtime based on user preference
- New export formats (Excel, JSON) can be added without modifying core
- Context (GradeExporterContext) holds strategy and delegates to it

**Benefits**:
- New export formats can be added without changing existing code
- Client can switch formats at runtime
- Each format encapsulated in separate class
- No if-else chains to select format

#### Pattern 3: Abstract Factory Pattern (DocumentFactory)
**Justification**:
- PDF export requires coordinated creation of PDF components (Header, Body, Footer)
- Document structure should be consistent across formats (PDF, Word, etc.)
- Factory ensures all parts of document family are created together
- Alternative document formats (Word, PowerPoint) need related families

**Benefits**:
- Related document parts created as family
- Easy to add new document formats
- Ensures document consistency
- Encapsulates object creation

### External Dependencies

**Data Access**:
- `UserRepository` - Retrieves student/teacher information
- `GradeRepository` (implicit) - Retrieves grade data
- `CourseRepository` (implicit) - Retrieves course information

**Factory Dependency**:
- `DocumentFactory` - Creates document components for PDF export

**UI Components**:
- Grade Viewer UI - Displays grades to users

---

## 3. ATTENDANCE MARKING COMPONENT

### Component Purpose
Manages attendance tracking with support for multiple marking methods (Manual, QR Code) and triggers attendance alerts.

### Public Interfaces

#### 3.1 Attendance Process Interface (Template Method)
```
Abstract Class: AttendanceProcess
Template Method:
├── recordAttendance(): void
│   ├── initiateAttendance(): void (abstract)
│   ├── markPresence(): void (abstract)
│   ├── validateAttendance(): void (concrete)
│   ├── generateReport(): void (abstract)
│   └── notifyRecipients(): void (concrete)

Concrete Implementations:
├── ManualAttendance
└── QRAttendance
```

**Template Method Workflow**:
```
recordAttendance() {
    initiateAttendance();      // Implementation-specific
    markPresence();            // Implementation-specific
    validateAttendance();      // Common logic
    generateReport();          // Implementation-specific
    notifyRecipients();        // Common logic (triggers notifications)
}
```

#### 3.2 Attendance Controller Interface
```
Interface: AttendanceController
Methods:
├── handleViewAttendance(String studentId): List<Attendance>
├── processAttendance(String date, String studentId, String status): void
├── markBulkAttendance(String classId, List<AttendanceRecord>): void
├── getAttendanceReport(String studentId, DateRange range): Report
└── triggerAttendanceAlert(String studentId): void
```

#### 3.3 Attendance DAO Interface
```
Interface: AttendanceDAO
Methods:
├── getAttendanceFromDB(String studentId): List<Attendance>
├── saveAttendance(Attendance record): void
├── updateAttendance(Attendance record): void
├── deleteAttendance(String attendanceId): void
└── getAttendanceByDate(String classId, LocalDate date): List<Attendance>
```

#### 3.4 Seat Manager Interface
```
Interface: SeatManager
Methods:
├── assignSeat(String studentId, Seat seat): void
├── getStudentSeat(String studentId): Seat
├── getSeatOccupant(Seat seat): String
├── getAvailableSeats(String classId): List<Seat>
└── manageSeatArrangement(List<SeatAssignment>): void
```

#### 3.5 Event Manager Interface
```
Interface: EventManager
Methods:
├── registerListener(EventListener listener): void
├── unregisterListener(EventListener listener): void
├── publishAttendanceEvent(AttendanceEvent event): void
├── publishAbsenceEvent(AbsenceEvent event): void
└── getEventHistory(String filter): List<Event>
```

### Pattern Justifications

#### Pattern 1: Template Method Pattern (AttendanceProcess)
**Justification**:
- Attendance recording has common steps regardless of method
- Different methods (Manual, QR) implement steps differently
- Common logic (validation, notification) should not be duplicated
- Workflow skeleton should be defined once; variations in specific steps

**Benefits**:
- Eliminates code duplication
- Enforces workflow consistency
- Easy to add new attendance methods (Biometric, Facial Recognition)
- Subclasses focus only on their specific implementations

**Workflow Steps**:
1. **initiateAttendance()** - Setup (varies by method)
   - Manual: Show attendance form
   - QR: Generate QR code
2. **markPresence()** - Record attendance (varies by method)
   - Manual: User selects present/absent
   - QR: Scan QR code
3. **validateAttendance()** - Check validity (COMMON)
   - Verify student exists
   - Verify class is in session
   - Check for duplicates
4. **generateReport()** - Create report (varies by method)
   - Manual: Generate text report
   - QR: Generate detailed scan report
5. **notifyRecipients()** - Send alerts (COMMON)
   - Alert if student absent
   - Alert if anomaly detected

#### Pattern 2: Observer Pattern (Event System)
**Justification**:
- Attendance events trigger multiple actions (notifications, alerts, reports)
- Loose coupling between attendance recording and notification system
- New listeners can be added without modifying attendance system
- Multiple listeners can react to same attendance event

**Benefits**:
- Attendance system doesn't know about notification system
- New listeners can be added without code changes
- Event-driven architecture enables flexible response

**Event Flow**:
```
Attendance Recorded
    ↓
AttendanceEvent Published
    ↓
EventManager Notifies Listeners:
    ├── AttendanceAlertListener
    │   └── Send notification if absent
    ├── ReportListener
    │   └── Update attendance report
    ├── AnalyticsListener
    │   └── Track attendance trends
    └── EmailListener
        └── Send parent notification
```

#### Pattern 3: Strategy Pattern (Attendance Methods)
**Justification**:
- While Template Method defines workflow, specific methods implement it
- Different methods (Manual, QR) have different algorithms
- New methods (Biometric, Facial) can be added as new strategies
- Encapsulation of method-specific logic

**Benefits**:
- Clear separation of concerns
- Easy to add new attendance methods
- Each method independently testable
- Flexible selection at runtime

### External Dependencies

**Data Access**:
- `AttendanceDAO` - Direct database access for attendance
- `AttendanceRepository` - Repository pattern for attendance data
- `DatabaseConnection` - Database connectivity

**Model Layer**:
- `Classroom` - Class information
- `StudentCollection` - Student collection access
- `Seat` - Seat entity
- `SeatManager` - Seat management

**Event System**:
- `EventManager` - Publishes attendance events
- `AttendanceAlertListener` - Handles attendance alerts

**Notification System**:
- Triggered via Observer pattern when attendance events occur

---

## 4. THIRD-PARTY INTEGRATION: SMS GATEWAY

### Component Purpose
Provides adapter interface between internal notification system and external SMS service providers (Twilio, Nexmo, AWS SNS).

### Public Interfaces

#### 4.1 SMS Gateway Adapter Interface
```
Interface: SMSGatewayAdapter
Methods:
├── sendSMS(String phoneNumber, String message): SMSResponse
├── sendSMSBatch(List<SMSRecord> records): List<SMSResponse>
├── checkDeliveryStatus(String messageId): DeliveryStatus
├── getCredits(): int
├── getDeliveryReport(DateRange range): DeliveryReport
└── validatePhoneNumber(String phoneNumber): boolean
```

**Return Types**:
```
Class SMSResponse {
    messageId: String
    status: DeliveryStatus
    timestamp: DateTime
    gateway: String
}

Enum DeliveryStatus {
    QUEUED
    SENT
    DELIVERED
    FAILED
    INVALID_NUMBER
}

Class DeliveryReport {
    totalSent: int
    delivered: int
    failed: int
    cost: double
    period: DateRange
}
```

#### 4.2 Internal SMS Notification Strategy Interface (connects to adapter)
```
Interface: SMSNotificationStrategy implements NotificationDeliveryStrategy
Methods:
├── sendNotification(String recipient, String message): void
├── validateRecipient(String recipient): boolean
├── retryFailedMessage(String messageId): void
└── getDeliveryStatus(String messageId): DeliveryStatus

Uses:
└── SMSGatewayAdapter (delegates SMS sending)
```

### Pattern Justifications

#### Pattern: Adapter Pattern (SMSGatewayAdapter)
**Justification**:
- External SMS Gateway has incompatible interface with internal system
- Internal system expects `NotificationDeliveryStrategy` interface
- External service expects `GatewayClient.send(gateway_request)` interface
- Adapter translates between two incompatible interfaces

**Incompatibility Details**:
```
Internal Interface (NotificationDeliveryStrategy):
└── sendNotification(String recipient, String message): void

External SMS Gateway Interface:
└── sendMessage(GatewayRequest): GatewayResponse
    where GatewayRequest requires:
    ├── apiKey: String
    ├── phoneNumbers: List[String]
    ├── messageBody: String
    ├── senderId: String
    ├── messagePriority: Int
    └── retryPolicy: RetryConfig
```

**Adapter Solution**:
```
SMSGatewayAdapter implements NotificationDeliveryStrategy {
    sendNotification(String recipient, String message) {
        GatewayRequest request = new GatewayRequest();
        request.apiKey = CONFIG.getApiKey();
        request.phoneNumbers = [recipient];
        request.messageBody = message;
        request.senderId = CONFIG.getSenderId();
        request.messagePriority = CONFIG.DEFAULT_PRIORITY;
        request.retryPolicy = CONFIG.getRetryPolicy();
        
        GatewayResponse response = externalGateway.sendMessage(request);
        return handleResponse(response);
    }
}
```

**Benefits**:
- Internal code doesn't know about external service format
- Easy to switch SMS providers (Twilio → Nexmo)
- External service changes don't affect internal code
- Single responsibility: Adapter only handles translation

**Adapter Responsibilities**:
1. **Message Translation**
   - Convert internal message format to gateway format
   - Handle character encoding, length limits

2. **Authentication**
   - Manage API keys securely
   - Handle token refresh
   - Validate credentials

3. **Error Handling**
   - Translate gateway error codes to internal codes
   - Implement retry logic
   - Log failures for debugging

4. **Response Mapping**
   - Convert gateway response to internal format
   - Track message delivery status
   - Extract delivery confirmation

5. **Logging & Monitoring**
   - Log all SMS sends
   - Track delivery rates
   - Monitor gateway health

### Integration Flow

```
User Action (e.g., Attendance Alert)
    ↓
AttendanceComponent publishes AttendanceEvent
    ↓
EventManager publishes event to listeners
    ↓
AttendanceAlertListener catches event
    ↓
NotificationManager is called
    ↓
SMSNotificationStrategy is selected
    ↓
SMSNotificationStrategy.sendNotification(phone, message)
    ↓
SMSGatewayAdapter receives call
    ├── Validates phone number
    ├── Translates message format
    ├── Authenticates with external gateway
    └── Sends to External SMS Gateway
        ↓
External SMS Gateway processes request
    ├── Validates recipient
    ├── Queues message
    └── Returns messageId
        ↓
SMSGatewayAdapter returns SMSResponse
    ├── messageId: "msg_12345"
    ├── status: SENT
    └── timestamp: 2024-05-07 10:30:00
        ↓
SMSNotificationStrategy logs delivery
    ↓
System monitors delivery status
    ├── Polls gateway for delivery confirmation
    └── Updates delivery status when confirmed
```

---

## 5. COMPONENT INTEGRATION MATRIX

| Component | Provides Interface | Consumes Interface | Design Pattern |
|-----------|------------------|-------------------|----------------|
| **Notification System** | NotificationDeliveryStrategy | EventListener, NotificationRepository | Strategy, Decorator, Bridge, Observer |
| **Grade Viewer** | GradeExportStrategy | DocumentFactory, GradeRepository | Singleton, Strategy, Abstract Factory |
| **Attendance Marking** | AttendanceProcess (Template) | EventManager, AttendanceDAO | Template Method, Observer |
| **SMS Gateway Adapter** | NotificationDeliveryStrategy | External SMS Service | Adapter |

---

## 6. DESIGN RATIONALE SUMMARY

### Why These Patterns?

1. **Strategy for Notification Delivery**
   - Problem: Multiple delivery methods with different algorithms
   - Solution: Define common interface, implement variations as strategies
   - Result: Easy to add new channels without modifying core

2. **Template Method for Attendance**
   - Problem: Multiple methods (Manual, QR) with common workflow
   - Solution: Define workflow skeleton in base class, implement variations
   - Result: No code duplication, consistent workflow

3. **Abstract Factory for UI Components**
   - Problem: Related objects (document parts, user families) need consistent creation
   - Solution: Create factory for each family to ensure coordination
   - Result: Easy to add new families without changing clients

4. **Bridge for Notifications**
   - Problem: Two independent dimensions (notification types, delivery methods)
   - Solution: Separate abstraction from implementation via bridge
   - Result: Prevents class explosion, enables flexible combinations

5. **Adapter for SMS Gateway**
   - Problem: Internal interface incompatible with external service
   - Solution: Create adapter to translate between interfaces
   - Result: Internal code independent of external service details

---

## 7. NFR COVERAGE

### Modularity (NFR-1): ✓
- Each component has clear interfaces
- Components can be deployed independently
- Dependencies are via interfaces, not direct coupling

### Extensibility (NFR-2): ✓
- Strategy Pattern enables new export/delivery formats
- Template Method enables new attendance methods
- Abstract Factory enables new document/user types
- Adapter enables new SMS providers

### Maintainability (NFR-3): ✓
- Clear interface contracts
- Design patterns reduce coupling
- Separation of concerns
- Easy to locate and modify specific functionality

### Scalability (NFR-4): ✓
- Singleton ensures resource efficiency
- Adapter enables load distribution
- Template Method enables batch processing
- Strategy enables optimization per algorithm

