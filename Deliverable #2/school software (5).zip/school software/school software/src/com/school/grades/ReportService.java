package com.school.grades;

public class ReportService {

    private GradeExporter exporter;

    public ReportService(GradeExporter exporter) {
        this.exporter = exporter;
    }

    public void generateReport(String studentId, String data) {
        exporter.exportGrades(studentId, data);
    }

    public static void main(String[] args) {
        LegacyReportPrinter legacy = new LegacyReportPrinter();
        GradeExporter adapter = new GradeExporterAdapter(legacy);
        ReportService service = new ReportService(adapter);
        service.generateReport("S1001", "Math: A, Science: B+");
    }
}
