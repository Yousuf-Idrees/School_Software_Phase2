package com.school.services;

import java.util.List;

public interface IGradeViewerService {
    List<Object> viewGrades(String studentId) throws Exception;
    
    Object getGradeByStudentAndCourse(String studentId, String courseId) throws Exception;
    
    boolean validateStudentId(String studentId);
    
    List<Object> getAllGrades() throws Exception;
}
