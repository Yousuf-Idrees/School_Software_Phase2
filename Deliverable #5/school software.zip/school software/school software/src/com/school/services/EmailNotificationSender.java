package com.school.services;

import com.school.model.INotificationSender;
import com.school.model.NotificationDeliveryStrategy;

public class EmailNotificationSender implements INotificationSender, NotificationDeliveryStrategy {
    
    @Override
    public void send(String recipient, String message) throws Exception {
        if (!validate(recipient)) {
            throw new Exception("Invalid email format: " + recipient);
        }
        performEmailSend(recipient, message);
    }

    @Override
    public boolean validate(String recipient) {
        return recipient != null && recipient.contains("@") && recipient.contains(".");
    }

    @Override
    public void sendNotification(String recipient, String message) {
        try {
            send(recipient, message);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void performEmailSend(String recipient, String message) {
        try {
            java.util.Properties props = new java.util.Properties();
            props.put("mail.smtp.host", "localhost");
            props.put("mail.smtp.port", "25");
            
        } catch (Exception e) {
            throw new RuntimeException("Failed to send email", e);
        }
    }
}
