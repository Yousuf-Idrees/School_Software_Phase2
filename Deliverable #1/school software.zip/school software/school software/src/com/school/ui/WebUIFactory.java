package com.school.ui;

// Internal interfaces (no 'public' here)
interface StudentForm { 
    void renderForm(); 
}

interface DataValidator { 
    boolean validateInput(String name, int age); 
}

interface StudentInfoUIFactory {
    StudentForm createForm();
    DataValidator createValidator();
}

// Implementations
class WebStudentForm implements StudentForm { 
    @Override
    public void renderForm() { 
        System.out.println("Rendering Web Form..."); 
    }
}

class WebDataValidator implements DataValidator { 
    @Override
    public boolean validateInput(String n, int a) { 
        return true; 
    }
}

// THE FILE MUST BE NAMED: WebUIFactory.java
public class WebUIFactory implements StudentInfoUIFactory {
    @Override
    public StudentForm createForm() { 
        return new WebStudentForm(); 
    }

    @Override
    public DataValidator createValidator() { 
        return new WebDataValidator(); 
    }
}