package com.school.sms;

public interface NotificationSender {
    void send(String recipient, String message);
}
