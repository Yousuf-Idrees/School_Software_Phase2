package com.school.adapters;

public class ExternalSMSServiceImpl implements IExternalSMSService {
    private String apiKey;
    private String endpoint;

    public ExternalSMSServiceImpl(String apiKey, String endpoint) {
        this.apiKey = apiKey;
        this.endpoint = endpoint;
    }

    @Override
    public boolean sendSMS(String phoneNumber, String message) throws Exception {
        if (!validatePhoneNumber(phoneNumber)) {
            throw new Exception("Invalid phone number format: " + phoneNumber);
        }
        
        if (message == null || message.trim().isEmpty()) {
            throw new Exception("Message cannot be empty");
        }
        
        return performHTTPPost(phoneNumber, message);
    }

    @Override
    public boolean validatePhoneNumber(String phoneNumber) {
        if (phoneNumber == null || phoneNumber.trim().isEmpty()) {
            return false;
        }
        
        String cleanedNumber = phoneNumber.replaceAll("[^0-9+]", "");
        return cleanedNumber.length() >= 10 && cleanedNumber.length() <= 15;
    }

    private boolean performHTTPPost(String phoneNumber, String message) {
        try {
            java.net.URL url = new java.net.URL(endpoint);
            java.net.HttpURLConnection connection = (java.net.HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Authorization", "Bearer " + apiKey);
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            String jsonBody = String.format("{\"to\":\"%s\",\"message\":\"%s\"}", phoneNumber, escapeJSON(message));
            
            try (java.io.OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonBody.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            int responseCode = connection.getResponseCode();
            return responseCode >= 200 && responseCode < 300;
        } catch (Exception e) {
            return false;
        }
    }

    private String escapeJSON(String str) {
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r");
    }
}
