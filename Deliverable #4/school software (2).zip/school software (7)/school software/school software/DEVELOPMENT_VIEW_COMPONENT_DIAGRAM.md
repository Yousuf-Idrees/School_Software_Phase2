# Development View: Component Diagram

## System Overview
The school software system is organized into modular components that interact through well-defined interfaces, implementing design patterns for extensibility, maintainability, and separation of concerns.

---

## 1. MODULAR COMPONENTS ARCHITECTURE

### 1.1 Notification System Component

**Responsibility**: Manages all notification delivery mechanisms across the system

**Internal Structure**:
- **Core Interfaces**:
  - `NotificationDeliveryStrategy` - Strategy for different delivery methods
  - `Notification` - Core notification interface
  - `NotificationSender` - Sender interface for bridge pattern

- **Concrete Strategies**:
  - `EmailNotificationStrategy` → Email notifications
  - `SMSNotificationStrategy` → SMS notifications via gateway
  - `InAppNotificationStrategy` → In-app dashboard notifications

- **Core Classes**:
  - `NotificationSystem` - Orchestrator
  - `NotificationManager` - Manager
  - `NotificationDeliveryClient` - Client
  - `BasicNotification` - Component
  - `NotificationDecorator` - Decorator base
  - `EmailDecorator` - Email decorator
  - `SMSDecorator` - SMS decorator

- **Notification Types** (Bridge Pattern):
  - `ExamNotification` (abstraction)
    - `MidtermNotification` (refined)
    - `FinalNotification` (refined)
  - `AnnouncementPanel` - Announcement notifications

- **Listeners & Observers**:
  - `AttendanceAlertListener` - Listens to attendance events
  - `EventListener` - Generic event listener

**Dependencies**:
  - Data Layer: `NotificationRepository`
  - Third-Party: SMS Gateway Adapter
  - UI Layer: `SMSAlertPanel`, `ExamNotificationPanel`, `AnnouncementPanel`

---

### 1.2 Grade Viewer Component

**Responsibility**: Provides grade viewing, exporting, and reporting functionality

**Internal Structure**:
- **Singleton Service**:
  - `GradeViewerService` - Thread-safe singleton for grade access

- **Export Strategies** (Strategy Pattern):
  - `GradeExportStrategy` (interface)
  - `CSVGradeExportStrategy` - CSV export
  - `PDFGradeExportStrategy` - PDF export
  - `PlainTextGradeExportStrategy` - Text export

- **Context & Controller**:
  - `GradeExporterContext` - Strategy context
  - `GradeExporter` - Export orchestrator
  - `GradeExportClient` - Client interface
  - `GradeController` - Controller

- **Report Generation**:
  - `ReportGenerationService` - Service layer
  - `ReportGenerator` - Generator
  - `ReportManager` - Manager
  - `ReportController` - Controller
  - `LegacyReportPrinter` - Legacy printer compatibility

**Dependencies**:
  - Data Layer: `UserRepository`, Grade database
  - Model Layer: `StudentCollection`, `StudentIterator`
  - UI Layer: View layer for grade display

---

### 1.3 Attendance Marking Component

**Responsibility**: Manages attendance tracking with multiple methods

**Internal Structure**:
- **Attendance Methods** (Template Method Pattern):
  - `AttendanceProcess` (template base)
  - `ManualAttendance` - Manual marking
  - `QRAttendance` - QR code scanning
  
- **Core Classes**:
  - `AttendanceController` - Controller
  - `AttendanceDAO` - Data access
  - `AttendanceRepository` - Repository

- **Seat Management**:
  - `SeatManager` - Manages classroom seats
  - `Seat` - Seat entity
  - `SeatType` - Seat type enum

- **Room Management**:
  - `ExamRoomMediator` - Exam room coordination
  - `ExamRoomClient` - Exam room client

- **Event System**:
  - `AttendanceAlertListener` - Alert listener
  - `EventManager` - Event management
  - `EventListener` - Generic listener

**Dependencies**:
  - Data Layer: `AttendanceDAO`, `AttendanceRepository`
  - Model Layer: `Classroom`, `StudentCollection`
  - Notification System: `AttendanceAlertListener`

---

## 2. DESIGN PATTERNS & INTERFACES

### 2.1 Abstract Factory Pattern (UI Families)

**Location**: `accounts/`, `model/`

**Pattern Implementation**:
```
UserAccountFactory (interface)
├── StudentAccountFactory
└── TeacherAccountFactory
    ├── createProfile()
    ├── createPermissions()
    └── createNotificationPreferences()

DocumentFactory (interface)
├── PDFDocumentFactory
│   ├── createHeader() → PDFHeader
│   ├── createBody() → PDFBody
│   └── createFooter() → PDFFooter
└── WordDocumentFactory
    ├── createHeader() → WordHeader
    ├── createBody() → WordBody
    └── createFooter() → WordFooter
```

**Interface Dependencies**:
- `DocumentFactory` → `DocumentHeader`, `DocumentBody`, `DocumentFooter`
- `UserAccountFactory` → `UserProfile`, `UserPermissions`

**Benefits**:
- Ensures UI families (PDF/Word documents, Student/Teacher accounts) are created cohesively
- Enables switching between families at runtime
- Encapsulates object creation logic

---

### 2.2 Template Method Pattern (Workflow Orchestration)

**Location**: `model/`, `controller/`

**Pattern Implementation**:

#### Course Workflow Template:
```
CourseCreation (abstract template)
├── OnlineCourse
│   ├── setupLearningManagement()
│   ├── configureVirtualClassroom()
│   └── setupAsynchronousAssignments()
└── OfflineCourse
    ├── setupPhysicalLocation()
    ├── configureClassroomSeating()
    └── setupInPersonExams()
```

#### Attendance Workflow Template:
```
AttendanceProcess (abstract template)
├── ManualAttendance
│   ├── initiateAttendance()
│   ├── markPresence()
│   └── generateReport()
└── QRAttendance
    ├── initiateQRCodeGeneration()
    ├── scanAndMarkPresence()
    └── generateReport()
```

**Interface Dependencies**:
- `AttendanceProcess` → `AttendanceDAO`, `AttendanceRepository`
- `CourseCreation` → `DocumentFactory`, `EventManager`

**Benefits**:
- Defines skeleton of workflow with customizable steps
- Enables different course types and attendance methods
- Maintains consistency across workflow variations

---

### 2.3 Bridge Pattern (Decoupling Abstractions from Implementations)

**Location**: `model/`, `controller/`

**Pattern Implementation**:

#### Exam Notification Bridge:
```
NotificationSender (implementor interface)
├── EmailSender
├── SMSSender
└── PushNotificationSender

ExamNotification (abstraction)
├── MidtermNotification
│   ├── notifyStudent(NotificationSender)
│   └── escalateIfMissed(NotificationSender)
└── FinalNotification
    ├── notifyStudent(NotificationSender)
    └── requireConfirmation(NotificationSender)
```

#### Assignment Storage Bridge:
```
Storage (implementor interface)
├── LocalStorage
├── CloudStorage
└── HybridStorage

Assignment (abstraction)
├── Homework
│   ├── submit(Storage)
│   └── validate(Storage)
└── Project
    ├── submit(Storage)
    ├── validate(Storage)
    └── trackProgress(Storage)
```

**Interface Dependencies**:
- `ExamNotification` → `NotificationSender`
- `Assignment` → `Storage`

---

### 2.4 Strategy Pattern (Algorithm Selection)

**Location**: `controller/`, `model/`

**Pattern Implementation**:

#### Grade Export Strategy:
```
GradeExportStrategy (interface)
├── CSVGradeExportStrategy
├── PDFGradeExportStrategy
└── PlainTextGradeExportStrategy

GradeExporterContext (context)
└── setStrategy(GradeExportStrategy)
    └── execute()
```

#### Notification Delivery Strategy:
```
NotificationDeliveryStrategy (interface)
├── EmailNotificationStrategy
├── SMSNotificationStrategy
└── InAppNotificationStrategy

NotificationManager (context)
└── sendNotification(strategy)
```

**Interface Dependencies**:
- `GradeExporterContext` → `GradeExportStrategy`
- `NotificationManager` → `NotificationDeliveryStrategy`

---

## 3. THIRD-PARTY INTEGRATION ARCHITECTURE

### 3.1 SMS Gateway Integration

**Third-Party Service**: External SMS Gateway (e.g., Twilio, AWS SNS)

**Adapter Pattern Implementation**:

```
External SMS Gateway API
    ↓
┌─────────────────────────────────────────┐
│   SMSGatewayAdapter (Adapter)           │
│  ┌─────────────────────────────────────┤
│  │ • Translates internal format to     │
│  │   SMS Gateway API format            │
│  │ • Handles authentication            │
│  │ • Maps error codes                  │
│  │ • Manages retry logic               │
│  └─────────────────────────────────────┤
└─────────────────────────────────────────┘
    ↑
Internal Interface
```

**Connection Points**:

1. **SMSNotificationStrategy** → SMS Gateway Adapter
   ```
   SMSNotificationStrategy.sendNotification(recipient, message)
       ↓
   SMSGatewayAdapter.send(phoneNumber, messageBody)
       ↓
   External SMS Gateway API
       ↓
   SMS Delivery
   ```

2. **Component Integration**:
   ```
   Notification System Component
   ├── SMSNotificationStrategy
   │   └── Uses: SMSGatewayAdapter
   │       ├── Authentication (API Key/Token)
   │       ├── Message Translation
   │       ├── Response Handling
   │       └── Error Logging
   └── Fallback: EmailNotificationStrategy
   ```

3. **Alert Flow**:
   ```
   Event Triggered (e.g., Attendance Alert)
       ↓
   AttendanceAlertListener
       ↓
   NotificationManager
       ↓
   SMSNotificationStrategy (selected)
       ↓
   SMSGatewayAdapter
       ↓
   External SMS Gateway
       ↓
   Student/Teacher SMS
   ```

**Adapter Responsibilities**:
- Convert internal `Notification` objects to SMS Gateway format
- Handle authentication with third-party service
- Manage rate limiting and throttling
- Translate error responses
- Log SMS delivery status
- Support retry mechanisms
- Cache authentication tokens

**Configuration Parameters**:
- API Key/Token
- Sender ID
- Endpoint URL
- Timeout settings
- Retry policy

---

## 4. COMPONENT INTERACTION FLOW

### 4.1 Grade Viewing Flow

```
User Interface
    ↓
GradeController
    ↓
GradeViewerService (Singleton)
    ↓
UserRepository
    ↓
Database
    ↓
[Grades Retrieved]
    ↓
ReportGenerationService
    ↓
GradeExporterContext (Strategy Pattern)
    ├── CSVGradeExportStrategy
    ├── PDFGradeExportStrategy (Abstract Factory for Document Parts)
    │   └── PDFDocumentFactory
    │       ├── createHeader() → PDFHeader
    │       ├── createBody() → PDFBody
    │       └── createFooter() → PDFFooter
    └── PlainTextGradeExportStrategy
    ↓
File System / UI Display
```

### 4.2 Attendance Marking Flow

```
Classroom
    ↓
AttendanceController
    ↓
AttendanceProcess (Template Method)
    ├── ManualAttendance
    │   ├── initiateAttendance()
    │   ├── markPresence()
    │   └── generateReport()
    └── QRAttendance
        ├── initiateQRCodeGeneration()
        ├── scanAndMarkPresence()
        └── generateReport()
    ↓
AttendanceDAO
    ↓
AttendanceRepository
    ↓
Database
    ↓
[Attendance Recorded]
    ↓
EventManager → EventListener
    ↓
AttendanceAlertListener
    ↓
NotificationSystem
    ├── NotificationManager
    ├── NotificationDeliveryStrategy (Strategy Pattern)
    │   ├── EmailNotificationStrategy
    │   ├── SMSNotificationStrategy → SMSGatewayAdapter → External SMS Gateway
    │   └── InAppNotificationStrategy
    ↓
Student/Teacher Notification
```

### 4.3 Exam Notification Flow

```
Exam Event Triggered
    ↓
ExamMediator
    ↓
ExamNotification (Bridge Pattern - Abstraction)
    ├── MidtermNotification
    └── FinalNotification
    ↓
NotificationSender (Bridge Pattern - Implementor)
    ├── EmailSender
    ├── SMSSender → SMSGatewayAdapter → External SMS Gateway
    └── PushNotificationSender
    ↓
Student Notification
```

### 4.4 Account Creation Flow

```
User Registration
    ↓
UserAccountFactory (Abstract Factory)
    ├── StudentAccountFactory
    │   ├── createProfile() → StudentProfile
    │   ├── createPermissions() → StudentPermissions
    │   └── createNotificationPreferences() → StudentNotificationPrefs
    └── TeacherAccountFactory
        ├── createProfile() → TeacherProfile
        ├── createPermissions() → TeacherPermissions
        └── createNotificationPreferences() → TeacherNotificationPrefs
    ↓
UserRepository
    ↓
Database
    ↓
Account Created
```

---

## 5. COMPONENT DEPENDENCIES MATRIX

| Component | Depends On | Interfaces Used | Pattern |
|-----------|-----------|-----------------|---------|
| Notification System | EventManager, Repository | NotificationDeliveryStrategy | Strategy, Decorator, Bridge |
| Grade Viewer | GradeViewerService, Repository | GradeExportStrategy, DocumentFactory | Singleton, Strategy, Abstract Factory |
| Attendance Marking | AttendanceDAO, EventManager | AttendanceProcess, SeatManager | Template Method, Observer |
| SMS Gateway Adapter | External SMS Service | SMSNotificationStrategy | Adapter |
| DocumentFactory | (none - creates objects) | DocumentFactory | Abstract Factory |
| UserAccountFactory | (none - creates objects) | UserAccountFactory | Abstract Factory |

---

## 6. EXTENSIBILITY POINTS

### 6.1 Notification System Extensions
- New notification strategies (push notifications, Slack, Teams)
- New notification types (Quiz notifications, Assignment notifications)
- New decorators (Encryption, Compression)

### 6.2 Grade Viewer Extensions
- New export formats (Excel, JSON, XML)
- New document factories (PowerPoint, Spreadsheet)
- New report generation algorithms

### 6.3 Attendance System Extensions
- New attendance methods (Biometric, Facial recognition)
- New notification triggers (Late arrivals, High absence)
- New reporting formats

### 6.4 Third-Party Integration Extensions
- Additional SMS gateways (Nexmo, MessageBird)
- Alternative payment gateways
- LMS integration adapters

---

## 7. NFRs REALIZATION

### 7.1 Modularity (NFR-1)
- **Components are independently deployable**
  - Notification System can be updated without affecting Grade Viewer
  - Attendance System can be scaled independently
  - SMS Gateway can be switched without code changes

### 7.2 Extensibility (NFR-2)
- **Strategy Pattern** allows new export formats and notification types
- **Abstract Factory** allows new document types and user families
- **Template Method** allows new attendance and course types
- **Adapter Pattern** allows integration of new third-party services

### 7.3 Maintainability (NFR-3)
- **Interfaces** clearly define contracts between components
- **Bridge Pattern** separates abstractions from implementations
- **Single Responsibility** each component has one reason to change
- **Dependency Injection** reduces coupling between components

### 7.4 Scalability (NFR-4)
- **Singleton Pattern** in GradeViewerService ensures resource efficiency
- **Template Method** allows efficient batch processing
- **Adapter Pattern** enables load distribution across multiple SMS gateways

---

## 8. COMPONENT RESPONSIBILITIES SUMMARY

| Component | Primary Responsibility | Secondary Responsibilities |
|-----------|----------------------|--------------------------|
| **Notification System** | Send notifications via multiple channels | Manage notification decorators, Handle retries |
| **Grade Viewer** | Display and export grades | Generate reports, Support multiple formats |
| **Attendance Marking** | Track student attendance | Alert on absences, Support multiple methods |
| **SMS Gateway Adapter** | Integrate external SMS service | Handle authentication, Translate protocols |
| **Abstract Factory (Accounts)** | Create user account families | Encapsulate object creation |
| **Abstract Factory (Documents)** | Create document families | Ensure consistent document structure |
| **Template Method (Attendance)** | Define attendance workflow | Allow customization at key points |
| **Template Method (Courses)** | Define course setup workflow | Support online and offline variations |

---

## 9. DEPLOYMENT VIEW

```
┌─────────────────────────────────────────────────────────┐
│                  School Software System                 │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │   UI Layer   │  │  Controller  │  │  Service     │  │
│  │   Components │  │   Layer      │  │  Layer       │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
│         ↑                ↑                  ↑           │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │ Notification │  │ Grade Viewer │  │ Attendance   │  │
│  │   Component  │  │  Component   │  │  Component   │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
│         ↑                ↑                  ↑           │
│  ┌────────────────────────────────────────────────┐    │
│  │          Data Access Layer                     │    │
│  │  (Repositories, DAOs, Database)               │    │
│  └────────────────────────────────────────────────┘    │
│                      ↑                                  │
│  ┌────────────────────────────────────────────────┐    │
│  │            Third-Party Integration             │    │
│  │  ┌────────────────────────────────────────┐   │    │
│  │  │   SMS Gateway Adapter                  │   │    │
│  │  │   ↓                                     │   │    │
│  │  │   External SMS Gateway Service         │   │    │
│  │  └────────────────────────────────────────┘   │    │
│  └────────────────────────────────────────────────┘    │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## 10. DESIGN RATIONALE

### Why Abstract Factory for UI?
- Different user types (Student/Teacher) require different UI components
- Different document types (PDF/Word) require different document structures
- Ensures families of objects are created together consistently

### Why Template Method for Workflows?
- Attendance can be manual or QR-based; course can be online or offline
- Common steps can be defined once in the base class
- Variations are encapsulated in subclasses
- Reduces code duplication

### Why Bridge Pattern for Notifications?
- Notification types (Exam, Announcement) are independent of delivery methods (Email, SMS)
- Can combine any notification type with any delivery method
- Adding new notification types doesn't require modifying senders
- Adding new senders doesn't require modifying notification types

### Why Strategy Pattern for Grade Export?
- Different export formats (CSV, PDF, Text) have different algorithms
- Can select format at runtime
- Easy to add new formats without modifying existing code
- Context (GradeExporterContext) manages strategy switching

### Why Adapter Pattern for SMS Gateway?
- External SMS Gateway has different interface than internal system
- Adapter translates between two incompatible interfaces
- Can switch SMS providers without changing internal code
- Encapsulates external service complexity

