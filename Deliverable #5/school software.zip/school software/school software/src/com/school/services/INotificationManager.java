package com.school.services;

import com.school.model.INotificationSender;
import java.util.List;

public interface INotificationManager {
    void sendNotificationToStudent(String studentId, String message, String notificationType) throws Exception;
    
    void sendNotificationToStudents(List<String> studentIds, String message, String notificationType) throws Exception;
    
    void registerNotificationStrategy(String strategyName, INotificationSender sender) throws Exception;
    
    void setDefaultStrategy(String strategyName) throws Exception;
    
    List<String> getAvailableStrategies();
    
    boolean validateStudentId(String studentId);
}
