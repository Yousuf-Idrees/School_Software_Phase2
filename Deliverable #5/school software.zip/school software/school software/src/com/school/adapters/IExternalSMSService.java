package com.school.adapters;

public interface IExternalSMSService {
    boolean sendSMS(String phoneNumber, String message) throws Exception;
    
    boolean validatePhoneNumber(String phoneNumber);
}
