package com.school.services;

import com.school.controller.GradeExportStrategy;
import com.school.controller.CSVGradeExportStrategy;
import com.school.controller.PDFGradeExportStrategy;
import com.school.controller.PlainTextGradeExportStrategy;

public class GradeExportServiceImpl implements IGradeExportService {
    private GradeExportStrategy csvStrategy;
    private GradeExportStrategy pdfStrategy;
    private GradeExportStrategy plainTextStrategy;

    public GradeExportServiceImpl() {
        this.csvStrategy = new CSVGradeExportStrategy();
        this.pdfStrategy = new PDFGradeExportStrategy();
        this.plainTextStrategy = new PlainTextGradeExportStrategy();
    }

    @Override
    public String exportGradesToCSV(String studentId) throws Exception {
        if (studentId == null || studentId.trim().isEmpty()) {
            throw new Exception("Invalid student ID for export");
        }
        return csvStrategy.export(studentId);
    }

    @Override
    public String exportGradesToPDF(String studentId) throws Exception {
        if (studentId == null || studentId.trim().isEmpty()) {
            throw new Exception("Invalid student ID for export");
        }
        return pdfStrategy.export(studentId);
    }

    @Override
    public String exportGradesToPlainText(String studentId) throws Exception {
        if (studentId == null || studentId.trim().isEmpty()) {
            throw new Exception("Invalid student ID for export");
        }
        return plainTextStrategy.export(studentId);
    }

    @Override
    public byte[] getExportedFileBytes(String studentId, String format) throws Exception {
        if (studentId == null || studentId.trim().isEmpty()) {
            throw new Exception("Invalid student ID");
        }
        if (format == null || format.trim().isEmpty()) {
            throw new Exception("Invalid export format");
        }

        String exportResult;
        switch (format.toLowerCase()) {
            case "csv":
                exportResult = exportGradesToCSV(studentId);
                break;
            case "pdf":
                exportResult = exportGradesToPDF(studentId);
                break;
            case "txt":
            case "text":
                exportResult = exportGradesToPlainText(studentId);
                break;
            default:
                throw new Exception("Unsupported export format: " + format);
        }

        return exportResult.getBytes("UTF-8");
    }
}
