error id: file:///C:/Users/omars/Desktop/Soft/Software%20GUI/school%20software/school%20software/src/com/school/controller/AttendanceController.java:com/school/data/AttendanceDAO#
file:///C:/Users/omars/Desktop/Soft/Software%20GUI/school%20software/school%20software/src/com/school/controller/AttendanceController.java
empty definition using pc, found symbol in pc: com/school/data/AttendanceDAO#
empty definition using semanticdb
empty definition using fallback
non-local guesses:

offset: 57
uri: file:///C:/Users/omars/Desktop/Soft/Software%20GUI/school%20software/school%20software/src/com/school/controller/AttendanceController.java
text:
```scala
package com.school.controller;

import com.school.data.@@AttendanceDAO;

import java.util.List;

public class AttendanceController {
    private AttendanceDAO attendanceDAO = new AttendanceDAO();

    // Ensure this method name is exactly what you call in the View
    public List<String> handleViewAttendance(String studentID) {
        if (studentID == null || studentID.trim().isEmpty()) {
            return null;
        }
        return attendanceDAO.getAttendanceFromDB(studentID);
    }

    public String processAttendance(String date, String id, String status) {
        return null ;
    }
}
```


#### Short summary: 

empty definition using pc, found symbol in pc: com/school/data/AttendanceDAO#