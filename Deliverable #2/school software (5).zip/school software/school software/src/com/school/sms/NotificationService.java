package com.school.sms;

public class NotificationService {

    private NotificationSender sender;

    public NotificationService(NotificationSender sender) {
        this.sender = sender;
    }

    public void sendAttendanceAlert(String phone, String studentName) {
        sender.send(phone, "Attendance alert for student: " + studentName);
    }

    public static void main(String[] args) {
        ThirdPartySMSGateway gateway = new ThirdPartySMSGateway();
        NotificationSender adapter = new SMSGatewayAdapter(gateway);
        NotificationService service = new NotificationService(adapter);
        service.sendAttendanceAlert("+201001234567", "Ahmed Kamal");
    }
}
