package com.school.data;

import java.sql.*;

public class VerifyDatabase {
    public static void main(String[] args) {
        String dbUrl = "jdbc:sqlite:school.db";
        
        try (Connection conn = DriverManager.getConnection(dbUrl)) {
            System.out.println("============================================================");
            System.out.println("DATABASE VERIFICATION - school.db");
            System.out.println("============================================================\n");
            
            // Get all tables
            DatabaseMetaData metaData = conn.getMetaData();
            ResultSet tables = metaData.getTables(null, null, "%", new String[]{"TABLE"});
            
            int tableCount = 0;
            while (tables.next()) {
                String tableName = tables.getString("TABLE_NAME");
                tableCount++;
                
                System.out.println("Table: " + tableName);
                System.out.println("------------------------------------------------------------");
                
                // Get row count
                try (Statement stmt = conn.createStatement();
                     ResultSet countResult = stmt.executeQuery("SELECT COUNT(*) FROM " + tableName)) {
                    countResult.next();
                    int rowCount = countResult.getInt(1);
                    System.out.println("Rows: " + rowCount);
                }
                
                // Get columns
                System.out.println("Columns:");
                ResultSet columns = metaData.getColumns(null, null, tableName, null);
                while (columns.next()) {
                    String colName = columns.getString("COLUMN_NAME");
                    String colType = columns.getString("TYPE_NAME");
                    System.out.println("  - " + colName + " (" + colType + ")");
                }
                
                // Show sample data
                try (Statement stmt = conn.createStatement();
                     ResultSet data = stmt.executeQuery("SELECT * FROM " + tableName + " LIMIT 1")) {
                    if (data.next()) {
                        System.out.println("Sample data (first row):");
                        for (int i = 1; i <= data.getMetaData().getColumnCount(); i++) {
                            System.out.println("    " + data.getMetaData().getColumnName(i) + ": " + data.getObject(i));
                        }
                    }
                }
                System.out.println();
            }
            
            if (tableCount == 0) {
                System.out.println("✗ NO TABLES FOUND!");
                System.out.println("Database is empty. Need to run initialization.");
            } else {
                System.out.println("✓ Successfully verified " + tableCount + " tables");
            }
            
            System.out.println("============================================================");
            System.out.println("Verification Complete!");
            System.out.println("============================================================");
            
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
