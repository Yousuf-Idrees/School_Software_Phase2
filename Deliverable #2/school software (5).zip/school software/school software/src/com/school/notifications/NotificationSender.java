package com.school.notifications;

/**
 * Implementor interface for Bridge Pattern
 * Defines the interface for different notification sending mechanisms
 */
public interface NotificationSender {
    void sendMessage(String message);
}
